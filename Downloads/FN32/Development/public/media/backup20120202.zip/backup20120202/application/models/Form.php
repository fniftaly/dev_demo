<?php
/**
 * Application_Model_User class.
 * 
 * @extends Application_Model_Entityabstract
 */
class Application_Model_Form extends Application_Model_Abstract {
    
	/**
	 * Can this user create contests?
	 * 
	 * @access public
	 * @return void
	 */    
	public function getMessageCountList($userid) {  
		if ($userid) {
			$sql = "CALL user_message_sent_count($userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}
    
	public function getMessageCountListMonthYear($userid,$rmonth,$ryear) {  
		if ($userid) {
            $monthStartDate = date("Y-m-d H:i:s", strtotime($ryear.'-'.$rmonth.'-01'.' 00:00:00'));
            $monthEndDate = date("Y-m-d H:i:s", strtotime('-1 second',strtotime('+1 month',strtotime($monthStartDate))));
            
			$sql = "CALL user_message_sent_count_my($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}

    	public function getMessageCountListLastPeriod($userid,$period) {  
		if ($userid) {
             $monthEndDate = date("Y-m-d H:i:s");
             $monthStartDate = date('Y-m-d H:i:s', strtotime('-'.$period.' days'));
            
			$sql = "CALL user_message_sent_count_my($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}
 
	public function getTotalOptIns($userid) {  
		if ($userid) {
			$sql = "CALL total_opt_ins($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}  
    
	public function getTotalOptOuts($userid) {  
		if ($userid) {
			$sql = "CALL total_opt_outs($userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}    
 
    	public function getTotalOptInsPeriod($userid,$period) {  
		if ($userid) {
             $monthEndDate = date("Y-m-d H:i:s");
             $monthStartDate = date('Y-m-d H:i:s', strtotime('-'.$period.' days'));
            
			$sql = "CALL total_opt_ins_period($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}
    
    	public function getTotalOptOutsPeriod($userid,$period) {  
		if ($userid) {
             $monthEndDate = date("Y-m-d H:i:s");
             $monthStartDate = date('Y-m-d H:i:s', strtotime('-'.$period.' days'));
            
			$sql = "CALL total_opt_outs_period($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}   
    
    public function reportCampaignHistory($userid) {
        if ($userid) {
            $sql = "CALL campaign_history_report($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }  
    
    public function reportCampaignMessageStatus($messageid) {
        if ($messageid) { 
            $sql = "CALL campaign_message_status($messageid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    } 
    
    public function listTopthreeFolders($userid) {
        if ($userid) { 
            $sql = "CALL top_three_folder_optins($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }    
    
    public function totalOptinsByFolder($folderid) {
        if ($folderid) { 
            $sql = "CALL count_total_optins_byfolder($folderid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;
    }  
    
    public function totalOptoutsByFolder($folderid) {
        if ($folderid) { 
            $sql = "CALL count_total_optouts_byfolder($folderid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;
    }     
 
    public function totalCampaignByFolder($folderid) {
        if ($folderid) { 
            $sql = "CALL count_total_campaign_byfolder($folderid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;
    }     
    
    public function insertFormDetails($webformUrlArray, $webformAttbArray) {
            $sql1 = "CALL add_webform_url($webformUrlArray[entityid], $this->escape('$webformUrlArray[urlname]'),$this->escape('$webformUrlArray[thankumsg]'),$this->escape('$webformUrlArray[descmsg]'),'$webformUrlArray[folderid]')";
            $rs1  = $this->query($sql1);
            if ($this->hasError()) { 
                $this->setError('An error occurred and the webform could not be added.<br />' . $this->getError(), $sql1.': '.$this->getError());
                return false;
            }else{
                    $webformUrlId = $rs1->id;
                    foreach($webformAttbArray as $webformAttb)
                    {
                        $sql2 = "CALL add_webform_attributes($webformUrlId,'$webformAttb[attb]','$webformAttb[attbtype]','$webformAttb[attboption]',$webformAttb[weightage])";
                        $rs2  = $this->query($sql2);	
                    } 
                    return true;
            }
    }  
    
    public function webformList($userid){
        if ($userid) { 
            $sql = "CALL webform_list($userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }else
                return NULL;
		}
		return NULL;        
    }
    
    public function webformDetail($userid,$formurl){
        if ($userid!=null AND $formurl!=null) { 
            $sql = "CALL webform_detail($userid,'$formurl')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }else
                return NULL;
		}
		return NULL;        
    }    
    
        public function insertFormValues($subscriberid,$formattbid,$formattbvalue){
        if ($formattbid!=null AND $formattbvalue!=null) { 
            $sql = "CALL add_webform_attribute_values($subscriberid,$formattbid,'$formattbvalue')";
            $rs  = $this->query($sql);
            if ($rs) {
                    return $rs->id;
            }else
                return false;
		}
		return false;        
    }
    
        public function getAttributeName($attributeid){
        if ($attributeid) { 
            $sql = "CALL get_attribute_name($attributeid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }else
                return NULL;
		}
		return NULL;        
    } 
    
        public function getSubscriber($phonenumber,$folderid){
            if ($phonenumber) { 
                $sql = "CALL get_subscriber($phonenumber,$folderid)";  //not opted out
                $rs  = $this->query($sql);
                if ($rs->hasRecords()) {
                        return $rs->fetchAll();
                }else
                    return NULL;
            }
            return NULL;        
       }   
       
    public function addSubscriberAllDetails($folderid,$phonenumber,$fname,$lname,$emailid,$bday,$lang,$webformid=null) { 
        //echo $folderid."<br>".$phonenumber."<br>".$fname."<br>".$lname."<br>".$emailid."<br>".$bday."<br>".$lang."<br>".$webformid;
       //echo $folderid.','.$phonenumber.','.$fname.','.$lname.','.$emailid.','.$bday.','.$lang.','.$webformid; exit;
        $this->error = false;
        $orig_input = $phonenumber;        
        
        // Clense the phonenumber
        $phonenumber = $this->cleanPhone($phonenumber);
        
        if (empty($phonenumber)) {
            return null;
        }
        
        if (strlen($phonenumber) < 10) {
            $this->setError('Invalid phonenumber "'.$orig_input.'" not added."');
            return false;
        }
        
        /*if ($this->checkEmailFormat($emailid)==0) {
            $this->setError('Invalid Email ID: "'.$emailid.'"."');
            return false;
        }*/        
        
        if($webformid)
               $sql = "CALL subscriber_add_with_metadata_webform($folderid, $phonenumber, '$fname', '$lname', '$emailid', '$bday', '$lang','webform',$webformid)";
            else
                $sql = "CALL subscriber_add_with_metadata($folderid, '$phonenumber', '$fname', '$lname', '$emailid', '$bday', '$lang')";
        $rs  = $this->query($sql);
         
        if ($this->hasError()) {
            $error = 'Could not add subscriber: "'.$orig_input.'", filtered to: "'.$phonenumber.'" to Folder.';
            $this->setError($error, $error.' - '.$sql.': '.$this->getError());
           	return false;
        }
        if ($rs->id < 0) {
       	    $this->setError('Subscriber ['.$phonenumber.'] already in this folder.');
       	    return false;
        }
        
        return $rs->id;
    }       

    public function cleanPhone($phonenumber) {
        return preg_replace("/[^0-9]/", "", $phonenumber);
    }  
    
    public function checkEmailFormat($emailid) {
        if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email))
             return 1;
        else
             return 0;
    } 
    
    public function getWebformDeatils($webformid){
        if ($webformid) { 
            $sql = "CALL get_webform_details($webformid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }else
                return NULL;
		}
		return NULL;        
    }   
    
    public function updateFormURL($webformid,$thankyoumsg,$descmsg,$folderids){ 
        if ($webformid) { 
            $sql = "CALL update_webform_url($webformid,'$thankyoumsg','$descmsg','$folderids')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }else
                return NULL;
		}
		return NULL;        
    }  
    
    public function removeFormAttribute($webformid){
        if ($webformid) { 
            $sql = "CALL remove_form_attribute($webformid)";
            $rs  = $this->query($sql);
            if (!$this->hasError()) {
                return true;
            }
		}
		return false;        
    }   
                    
    public function addFormAttribute($webformid,$webformAttbArray){ 
        if ($webformid) {             
            foreach($webformAttbArray as $webformAttb)
            {
                $sql = "CALL add_webform_attributes($webformid,'$webformAttb[attb]','$webformAttb[attbtype]','$webformAttb[attboption]',$webformAttb[weightage])";
                $rs  = $this->query($sql);
            }     
            return true;   
		}
		return false;        
    }                      
    
    public function makeShortUrl($url){ 
       $tinyurl = new Zend_Service_ShortUrl_MetamarkNet();
       return $tinyurl->shorten($url);     
    }
    
    public function getSubscriberDataById($subscid,$userid){ 
        if ($subscid) { 
            $sql = "CALL get_subscriber_data_byid($subscid,$userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }else
                return NULL;
		}
		return NULL;     
    }   
    
    public function getSubscriberDataValueById($subscid,$formurlid){ 
        if ($subscid) { 
            $sql = "CALL get_subscriber_datavalue_byid($subscid,$formurlid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }else
                return NULL;
		}
		return NULL;     
    }     
    
    public function multiArraySearch($srchvalue,$sercharray){
        foreach($sercharray as $srchkey => $srch){
            if(in_array($srchvalue,$srch)){
                return $srchkey;
                break;
            }else{
                    return false;
            }
        }
    }  
    
    public function monthList(){
        $monthArray = Array(
            "01" => "Jan",
            "02" => "Feb",
            "03" => "Mar",
            "04" => "Apr",
            "05" => "May",
            "06" => "Jun",
            "07" => "Jul",
            "08" => "Aug",
            "09" => "Sep",
            "10" => "Oct",
            "11" => "Nov",
            "12" => "Dec"
        );
        return $monthArray;
    }
    
    public function dateList(){
        $dateArray = Array();
        for($i=1;$i<=31;$i++){
            $dateArray[$i] = $i;
        }
        return $dateArray;
    }    
    
    public function weightage(){
        $weightageList = array();
        for($i=0;$i<30;$i++){
            $weightageList[$i] = $i;
        }
        return $weightageList;
    }
    
    public function getFolderName($folderid){
		if ($folderid) {            
			$sql = "CALL get_foldername_from_entityid($folderid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->foldername) {
                    return $rs->foldername;
                }
            }

		}
		return NULL;                
    }   
    
    public function deleteWebformById($formid){
        $sql = "CALL delete_webform_url($formid)";
        $rs  = $this->query($sql);
        if ($this->hasError()) { 
            return FALSE;
        }else{
            return TRUE;
        }
    }
    
}
