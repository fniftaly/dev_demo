<?php
/**
 * Application_Model_Userentity class.
 * 
 * This is here because users are an entity, but a special kind. The User model
 * does not extend the entity abstract, so this model does and allows you to manage
 * users as an entity. Might need to rethink this later but for now it will do.
 * 
 * @extends Application_Model_Entityabstract
 */
class Application_Model_Userentity extends Application_Model_Entityabstract {
    
    // Will figure out a better way later...
    public function __construct(Application_Model_User $user, $id = null, $loadby = 'id') {
    	parent::__construct($user, $id, $loadby);
    	$this->_typeid = 5;
    }
    
    /**
     * Update a user meta data.
     *
     * @param array $meta Key=>Pair values for location meta data
     * @return bool Status of the update
     */
    public function update(array $meta) {
        // I think this will be moved to Entityabstract.
        // Update each field individually? Or require the API user
        // to send all params and just update all at once?
        
        return true;
    }
    
    public function encryptPassword($password) {
        return md5($password);
    }
    
    /**
     * Update a single meta value.
     * 
     * @access public
     * @return bool
     */
    public function updatePassword($password) {
    	$password = $this->encryptPassword($password);
    	$password = $this->_dbh->real_escape_string($password);
        $sql = "CALL entity_meta_update($this->id, 25, '$password', {$this->user->getId()})";
	$rs = $this->query($sql);
		
        if ($this->hasError()) {
            error_log($this->getError());
            $this->error = 'Unable to update entity meta information.';
            return false;
        }
        
        return true;
    }
    
    /**
     * Return the current status of this user.
     * 
     * @access public
     * @return int Current status id of this user.
     */
    public function getStatus($verbose = true) {
        if ($verbose) {
            $types = $this->getStatusTypes();
            
            foreach ($types as $type) {
                if ($type['id'] == $this->status) return $type['name'];
            }
        }
        
        return $this->status;
    }
    
    /**
     * This is a dangerous function, but I need it right now until
     * I figure out a better way. It will return the base entity 
     * data (most importantly ID's) for all entities that are of the
     * passed type.
     * 
     * @access public
     * @return void
     */
    public function getAll() {
    	$users = array();
    	
    	$sql = "CALL entity_get_type(5)";
    	$rs  = $this->query($sql);
    	
    	foreach ($rs->fetchAll() as $user) {
    		$id = (int) $user['id'];
    		$users[] = new Application_Model_User($id);
    	}
    	
    	return $users;
    }
}
