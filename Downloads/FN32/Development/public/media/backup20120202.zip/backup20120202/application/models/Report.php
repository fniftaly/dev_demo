<?php
/**
 * Application_Model_User class.
 * 
 * @extends Application_Model_Entityabstract
 */
class Application_Model_Report extends Application_Model_Abstract {
    
	/**
	 * Can this user create contests?
	 * 
	 * @access public
	 * @return void
	 */    
	public function getMessageCountList($userid) {  
		if ($userid) {
			$sql = "CALL user_message_sent_count($userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}
    
	public function getMessageCountListMonthYear($userid,$rmonth,$ryear) {  
		if ($userid) {
            $monthStartDate = date("Y-m-d H:i:s", strtotime($ryear.'-'.$rmonth.'-01'.' 00:00:00'));
            $monthEndDate = date("Y-m-d H:i:s", strtotime('-1 second',strtotime('+1 month',strtotime($monthStartDate))));
            
			$sql = "CALL user_message_sent_count_my($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}

    	public function getMessageCountListLastPeriod($userid,$period) {  
		if ($userid) {
             $monthEndDate = date("Y-m-d H:i:s");
             $monthStartDate = date('Y-m-d H:i:s', strtotime('-'.$period.' days'));
            
			$sql = "CALL user_message_sent_count_my($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}
 
	public function getTotalOptIns($userid) {  
		if ($userid) {
			$sql = "CALL total_opt_ins($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}  
    
	public function getTotalOptOuts($userid) {  
		if ($userid) {
			$sql = "CALL total_opt_outs($userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}   
    
	public function getTotalSubscribers($userid) {  
		if ($userid) {
			$sql = "CALL total_subscribers($userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}     
        
        
        
        public function getTotalOutBoundByPeriod($userid,$period) {  
		if ($userid) {
             $monthEndDate = date("Y-m-d H:i:s");
             $monthStartDate = date('Y-m-d H:i:s', strtotime('-'.$period.' days'));
             //echo  $monthEndDate;
             //echo $monthStartDate;
             //exit;
            
			$sql = "CALL total_out_bound_period($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}
        
        public function getTotalCampaignMessagesCountByuser($userid) {
        if ($userid) {
            $sql = "CALL count_campaign_history($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;    
    } 
    
        public function getTotalCampaignCountByuser($userid) {
        if ($userid) {
            $sql = "CALL report_count_campaign_byid_2($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;    
    }    
        
        
 
    	public function getTotalOptInsPeriod($userid,$period) {  
		if ($userid) {
             $monthEndDate = date("Y-m-d H:i:s");
             $monthStartDate = date('Y-m-d H:i:s', strtotime('-'.$period.' days'));
            
			$sql = "CALL total_opt_ins_period($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}
    
    	public function getTotalOptOutsPeriod($userid,$period) {  
		if ($userid) {
             $monthEndDate = date("Y-m-d H:i:s");
             $monthStartDate = date('Y-m-d H:i:s', strtotime('-'.$period.' days'));
            
			$sql = "CALL total_opt_outs_period($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;        
	}   
    
    public function reportCampaignHistory($userid) {
        if ($userid) {
            $sql = "CALL campaign_history_report($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    } 
    
    public function reportCampaignHistoryByPeriod($userid,$startdate,$enddate) {
        if ($userid) {
            $sql = "CALL campaign_history_report_byperiod($userid,'$startdate','$enddate')";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) { 
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }    
    
    public function reportCampaignMessageStatus($messageid) {
        if ($messageid) { 
            $sql = "CALL campaign_message_status($messageid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    } 
    
    public function listTopthreeFolders($userid) {
        if ($userid) { 
            $sql = "CALL top_three_folder_optins($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }  
    
    public function listTopthreeKeywords($userid) {
        if ($userid) { 
            $sql = "CALL top_three_keyword_optins($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }     
    
    public function totalSubscribersByFolder($folderid,$startdate=0,$enddate=0) {
        if ($folderid) { 
            if($startdate==0 OR $enddate==0)
            {
                $sql = "CALL count_total_subscribers_byfolder($folderid)";
            }else{ 
                $sql = "CALL count_total_subscribers_byfolder_byperiod($folderid,'$startdate','$enddate')";
                 
            }         
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;
    }     
    
    public function totalOptinsByFolder($folderid,$startdate=0,$enddate=0) {
        if ($folderid) { 
            if($startdate==0 OR $enddate==0)
            {
                $sql = "CALL count_total_optins_byfolder($folderid)";
            }else{ 
                $sql = "CALL count_total_optins_byfolder_byperiod($folderid,'$startdate','$enddate')";
                 
            }         
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;
    }  
    
    
    public function totalOptoutsByFolder($folderid,$startdate=0,$enddate=0) {
        if ($folderid) { 
            if($startdate==0 OR $enddate==0)
            {
                $sql = "CALL count_total_optouts_byfolder($folderid)";
            }else{ 
                $sql = "CALL count_total_optouts_byfolder_byperiod($folderid,'$startdate','$enddate')";
            }              

            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;
    }     
 
    public function totalCampaignByFolder($folderid,$startdate=0,$enddate=0) {
        if ($folderid) { 
            if($startdate==0 OR $enddate==0)
            {
                $sql = "CALL count_total_campaign_byfolder($folderid)";
            }else{ 
                $sql = "CALL count_total_campaign_byfolder_byperiod($folderid,'$startdate','$enddate')";
            }             
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;
    }  
    
 
        public function getTotalOutboundMessages($folderid,$startdate=0,$enddate=0) {
        if ($folderid) {
            if($startdate==0 OR $enddate==0)
            {
                $sql = "CALL count_totaloutbound_byfolder($folderid)";
            }else{ 
                $sql = "CALL count_totaloutbound_byfolder_byperiod($folderid,'$startdate','$enddate')";
            }             
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;    
    }   
    
        public function getTotalCampaignMessagesByFolder($folderid,$startdate=0,$enddate=0) {
        if ($folderid) {
            if($startdate==0 OR $enddate==0)
            {
                $sql = "CALL count_totalcampaign_byfolder($folderid)";
            }else{ 
                $sql = "CALL count_totalcampaign_byfolder_byperiod($folderid,'$startdate','$enddate')";
            }             
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return 0;    
    }     
    
    public function totalOptinsByKeyword($keywordid) {
        if ($keywordid) { 
            $sql = "CALL count_total_optins_bykeyword($keywordid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;
    }  
    
    
    public function totalOptoutsByKeyword($keywordid) {
        if ($keywordid) { 
            $sql = "CALL count_total_optouts_bykeyword($keywordid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;
    }     
 
    public function totalCampaignByKeyword($keywordid) {
        if ($keywordid) { 
            $sql = "CALL count_total_campaign_bykeyword($keywordid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;
    }    
    
    public function totalCampaignByUser($userid,$period) {
        if ($userid) { 
            $sql = "CALL count_total_campaign_byuser($userid,$period)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;
    }      
    
    public function findChildUser($userid) {
        if ($userid) { 
            $sql = "CALL find_child_user($userid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }  
    
    public function findChildEntityList($userid,$type,$searchvalue="") {
        if ($userid) { 
            $sql = "CALL find_childentity_list($userid,$type,'$searchvalue')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }   
    
    public function getTotalSubscriberByPeriod($userid,$period) {  
		if ($userid) {
             $monthEndDate = date("Y-m-d H:i:s");
             $monthStartDate = date('Y-m-d H:i:s', strtotime('-'.$period.' days'));
            
			$sql = "CALL folder_get_subscribers_period($userid,'$monthStartDate','$monthEndDate')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->total) {
                    return $rs->total;
                }
            }

		}
		return NULL;        
	} 
    
    public function getTotalSubscriberByFolder($folderid) {  
		if ($folderid) {       
			$sql = "CALL folder_get_subscribers_inout($folderid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->num_rows) {
                    return $rs->num_rows;
                }
            }

		}
		return 0;        
	} 
    
    public function getTotalSubscriberByKeyword($keywordid) {  
		if ($keywordid) {           
			$sql = "CALL folder_get_subscribers_inout_bykeyword($keywordid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->num_rows) {
                    return $rs->num_rows;
                }
            }

		}
		return NULL;        
	}   
    
    public function checkAdminUser($userid) {  
        if ($userid) { 
            $sql = "CALL report_check_adminuser($userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->value == 'on') {
                    return TRUE;
                }
            }else{
                    return FALSE;
            }            
        }else{
                return FALSE;
        }
    }
    
        public function reportCountTotalKeywordByUserId($userid,$startdate=0,$enddate=0) {
        if ($userid) { 
            if($startdate==0 OR $enddate==0)
            {
                //$sql1 = "CALL report_count_keywords_byid_1($userid)";
                
                if($this->checkAdminUser($userid))
                    $sql3 = "CALL report_count_keywords_byid_3($userid)";
                else
                    $sql2 = "CALL report_count_keywords_byid_2($userid)";
            }else{ 
                if($this->checkAdminUser($userid))
                    $sql3 = "CALL report_count_keywords_byid_3($userid)";
                else
                    $sql2 = "CALL report_count_keywords_byid_2($userid)";
                /*$sql1 = "CALL report_count_keywords_byid_byperiod_1($userid,'$startdate','$enddate')";
                $sql2 = "CALL report_count_keywords_byid_byperiod_2($userid,'$startdate','$enddate')";
                $sql3 = "CALL report_count_keywords_byid_byperiod_3($userid,'$startdate','$enddate')";*/
            }   
            $total = 0;
            /*$rs1  = $this->query($sql1); //echo "<pre>"; print_r($rs1); exit;
            if($rs1->total)
                 $total += $rs1->total;*/
            if(!empty($sql2)){
                $rs2  = $this->query($sql2); 
                if($rs2->total)
                     $total += $rs2->total;                 
            }
 
            if(!empty($sql3)){
                $rs3  = $this->query($sql3); 
                if($rs3->total)
                     $total += $rs3->total;                 
            }
            
            return $total;
		}
		return 0;    
    }  
    
        public function reportCountTotalSubscribersByUserId($userid,$startdate=0,$enddate=0) {
        if ($userid) { 
            if($startdate==0 OR $enddate==0)
            {
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_subscribers_byid_1($userid)";
                else    
                    $sql2 = "CALL report_count_subscribers_byid_2($userid)";
            }else{ 
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_subscribers_byid_byperiod_1($userid,'$startdate','$enddate')";
                else
                    $sql2 = "CALL report_count_subscribers_byid_byperiod_2($userid,'$startdate','$enddate')";
            }   
            $total = 0;
            
            if(!empty($sql1)){
                $rs1  = $this->query($sql1); //echo "<pre>"; print_r($rs1); exit;
                if($rs1->total)
                     $total += $rs1->total;                
            }            

            if(!empty($sql2)){
                $rs2  = $this->query($sql2); 
                if($rs2->total)
                     $total += $rs2->total;                  
            }         
            
            return $total;
		}
		return 0;    
    }     
    
        public function reportCountTotalOptinsByUserId($userid,$startdate=0,$enddate=0) {
        if ($userid) { 
            if($startdate==0 OR $enddate==0)
            {
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_optins_byid_1($userid)";
                else    
                    $sql2 = "CALL report_count_optins_byid_2($userid)";
            }else{ 
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_optins_byid_byperiod_1($userid,'$startdate','$enddate')";
                else
                    $sql2 = "CALL report_count_optins_byid_byperiod_2($userid,'$startdate','$enddate')";
            }   
            $total = 0;
            
            if(!empty($sql1)){
                $rs1  = $this->query($sql1); //echo "<pre>"; print_r($rs1); exit;
                if($rs1->total)
                     $total += $rs1->total;                
            }            

            if(!empty($sql2)){
                $rs2  = $this->query($sql2); 
                if($rs2->total)
                     $total += $rs2->total;                  
            }  

            return $total;
		}
		return 0;    
    }  
    
        public function reportCountTotalOptoutsByUserId($userid,$startdate=0,$enddate=0) {
        if ($userid) { 
            if($startdate==0 OR $enddate==0)
            {
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_optouts_byid_1($userid)";
                else
                    $sql2 = "CALL report_count_optouts_byid_2($userid)";
            }else{ 
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_optouts_byid_byperiod_1($userid,'$startdate','$enddate')";
                else
                    $sql2 = "CALL report_count_optouts_byid_byperiod_2($userid,'$startdate','$enddate')";
            }   
            $total = 0;
            
            if(!empty($sql1)){
                $rs1  = $this->query($sql1); //echo "<pre>"; print_r($rs1); exit;
                if($rs1->total)
                     $total += $rs1->total;                
            }            

            if(!empty($sql2)){
                $rs2  = $this->query($sql2); 
                if($rs2->total)
                     $total += $rs2->total;                  
            }  

            return $total;
		}
		return 0;    
    }  
    
        public function reportCountTotalCampaignsByUserId($userid,$startdate=0,$enddate=0) {
        if ($userid) { 
            if($startdate==0 OR $enddate==0)
            {
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_campaign_byid_1($userid)";
                else
                    $sql2 = "CALL report_count_campaign_byid_2($userid)";
            }else{ 
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_campaign_byid_byperiod_1($userid,'$startdate','$enddate')";
                else
                    $sql2 = "CALL report_count_campaign_byid_byperiod_2($userid,'$startdate','$enddate')";
            }   
            $total = 0;
            
            if(!empty($sql1)){
                $rs1  = $this->query($sql1); //echo "<pre>"; print_r($rs1); exit;
                if($rs1->total)
                     $total += $rs1->total;                
            }            

            if(!empty($sql2)){
                $rs2  = $this->query($sql2); 
                if($rs2->total)
                     $total += $rs2->total;                  
            }  

            return $total;
		}
		return 0;    
    }   
    
        public function reportCountTotalCampaignMessagesByUserId($userid,$startdate=0,$enddate=0) {
        if ($userid) { 
            if($startdate==0 OR $enddate==0)
            {
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_campaignmessage_byid_1($userid)";
                else
                    $sql2 = "CALL report_count_campaignmessage_byid_2($userid)";
            }else{ 
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_campaignmessage_byid_byperiod_1($userid,'$startdate','$enddate')";
                else
                    $sql2 = "CALL report_count_campaignmessage_byid_byperiod_2($userid,'$startdate','$enddate')";
            }   
            $total = 0;
            
            if(!empty($sql1)){
                $rs1  = $this->query($sql1); //echo "<pre>"; print_r($rs1); exit;
                if($rs1->total)
                     $total += $rs1->total;                
            }            

            if(!empty($sql2)){
                $rs2  = $this->query($sql2); 
                if($rs2->total)
                     $total += $rs2->total;                  
            }  

            return $total;
		}
		return 0;    
    } 
    
        public function reportCountTotalMessagesByUserId($userid,$startdate=0,$enddate=0) {
        if ($userid) { 
            if($startdate==0 OR $enddate==0)
            {
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_totalmessage_byid_1($userid)";
                else
                    $sql2 = "CALL report_count_totalmessage_byid_2($userid)";
            }else{ 
                if($this->checkAdminUser($userid))
                    $sql1 = "CALL report_count_totalmessage_byid_byperiod_1($userid,'$startdate','$enddate')";
                else
                    $sql2 = "CALL report_count_totalmessage_byid_byperiod_2($userid,'$startdate','$enddate')";
            }   
            $total = 0;
            
            if(!empty($sql1)){
                $rs1  = $this->query($sql1); //echo "<pre>"; print_r($rs1); exit;
                if($rs1->total)
                     $total += $rs1->total;                
            }            

            if(!empty($sql2)){
                $rs2  = $this->query($sql2); 
                if($rs2->total)
                     $total += $rs2->total;                  
            }  

            return $total;
		}
		return 0;    
    }   
    

    public function sendRportTo(){
        $sendReportArray = Array(
                                  '0' => Array(
                                                'id' => '0',
                                                'typeidextra' => '1',
                                                'user' => 'pankajd',
                                                'email' => 'pankajd.sdei@smartdatainc.net'
                                         ),
                                  '1' => Array(
                                                'id' => '187',
                                                'typeidextra' => '1',
                                                'user' => 'Wais',
                                                'email' => 'wais@textmunication.com'
                                         ),
                                  '2' => Array(
                                                'id' => '786',
                                                'typeidextra' => '2',
                                                'user' => 'brandstandmm',
                                                'email' => 'jsaunders@brandstandgroup.com'
                                         ),     
                                  '3' => Array(
                                                'id' => '185',
                                                'typeidextra' => '1',
                                                'user' => 'pfacadmin',
                                                'email' => 'nikki@pizzafactoryinc.com'
                                         )             
                           );      
        return $sendReportArray;
    }    
    
    
    public function getWeeklyReport($userid=null,$usertypeid=null){
        $enddate = date("Y-m-d H:i:s");
        $startdate = date('Y-m-d H:i:s', strtotime('-7 days')); //echo $userid.'##'.$usertypeid.'##'.$enddate.'##'.$startdate;
        
        if($userid!=null AND $usertypeid!=null)
        {
            if($usertypeid==1)
                $sql = "CALL get_weekly_report_bywhitelabel($userid,'$startdate','$enddate')";
            elseif($usertypeid==2)
                $sql = "CALL get_weekly_report_byagent($userid,'$startdate','$enddate')";
        }else
            $sql = "CALL get_weekly_report('$startdate','$enddate')";
        
        $rs  = $this->query($sql); 
        if ($rs->hasRecords()) {
                return $rs->fetchAll();  
        }
    }
    
    
}
