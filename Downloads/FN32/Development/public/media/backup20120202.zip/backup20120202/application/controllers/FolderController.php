<?php

class FolderController extends AuthorizedController {
    
    
    /**
     * Redirector - defined for code completion
     *
     * @var Zend_Controller_Action_Helper_Redirector
     */
    protected $_redirector = null;
 
    public function init()
    {
        $this->_redirector = $this->_helper->getHelper('Redirector');              
    }    
    
    /**
     * Index will list all the users folders.
     * 
     * @access public
     */
    public function indexAction() {
    	// Set any add folder errors into the view
        $this->view->adderror = $this->_getParam('adderror');        
		$this->view->success = $this->_getParam('success');

        $folderObj = new Application_Model_Folder($this->user);
        if($this->request->isPost()){
            $iphonenumber = $this->request->getParam('phonesrch');
            if($iphonenumber != ""){
                $folderidArray = $folderObj->getFoldersByPhoneNumber($iphonenumber); 
                $folderidstr = "";
                foreach($folderidArray as $key => $folder){
                    if($key != 0)
                        $folderidstr.=",";
                    
                    $folderidstr.=$folder['folderid'];
                }
                $user_folders = $folderObj->getFoldersByfolderidstring($folderidstr);
            }else{
                $user_folders = $this->user->getFolders();
            }
        }else{
                $user_folders = $this->user->getFolders();
        }
    	
        /*
        $folders      = array();
        
        foreach ($user_folders as $id) {
            $folders[] = new Application_Model_Folder($this->user, $id);
        }*/
        
        $this->view->folders = $user_folders;
    }
    
    /**
     * Add a new folder to this users account.
     * 
     * @access public
     */
    public function addAction() {
    	if ($this->request->isPost()) {
    		$name   = trim($this->request->name);
    		$page   = trim($this->request->reqpage);
    		$action = trim($this->request->reqaction);
    		
    		if (empty($name)) {
    			$adderror = 'A name must be provided for the new folder.';
    			return $this->_forward($action,$page,null,array('adderror' => $adderror));
    		}
            
    		$folder = new Application_Model_Folder($this->user);
    		
            /**
             * REPLACE THIS
             */
            // Set up the Folder meta data
            $meta         = array();
            $meta['name'] = $name;
            
            $success = $folder->addWithMeta($meta);
            
            
            /**
             * WITH THIS
             */
            /*
            $exists     = $folder->folderExists($name);
            $other_user = $folder->isValid();
            
            /**
             * If folderExists returns false, that means there was either a problem in the database, the folder was not found,
             * or the folder was found but the user can't access it.
             * 
             * If folder->isValid() is true, that means the folder was found
             * 
             * So combine these and...
             * 
             * if $exists = true, don't let the user create the folder
             * if $exists = false && $other_user = true, let the user create the folder
             * if $exists = false && $other_user = false, let the user create the folder
             * 
             * This however does not prevent 
             */
            /*
            if ($exists) {
                $adderror = 'A folder by that name already exists.';
                return $this->_forward($action,$page,null,array('adderror' => $adderror));
            } else {
                // Set up the Folder meta data
                $meta         = array();
                $meta['name'] = $name;
                
                $success = $folder->addWithMeta($meta);
    		}
            */
            
   			return $this->_forward($action,$page,null,array('success' => $success));
    	}
    }
    
    function csv2array($input,$delimiter=',',$enclosure='"',$escape='\\'){
	    $fields=explode($enclosure.$delimiter.$enclosure,substr($input,1,-1));
	    foreach ($fields as $key=>$value)
	        $fields[$key]=str_replace($escape.$enclosure,$enclosure,$value);
	    return($fields);
	}

    
    /**
     * See messages sent to a particular folder.
     * 
     * @access public
     */
    public function viewAction() { 
    	// Defaults
    	$error       = null;
    	$foldername  = 'Not Found';
    	$folderid    = null;
    	$subscribers = array();
    	$message     = null;
        
        $folderList = $this->user->getFolders();
        
        $id = $this->request->getParam('id');
        $from = $this->request->getParam('from');
        if ($from && $from == 'keyword') {
        	$link = '/messages/keyword/';
	        $kid = $this->request->getParam('kid');
	        $keyword = $this->request->getParam('keyword');
	        
	        if ($kid && $keyword) {
	        	$link .= 'id/' . $kid;
	        	$text = 'Back to keyword ' . $keyword;
	        } else {
	        	$text = 'Back to keywords';
	        }
        } else {
        	$link = '/folder/';
        	$text = 'Back to folders';
        }
        
        $this->view->backtolink = $link;
        $this->view->backtotext = $text;
        
        $folder = new Application_Model_Folder($this->user, $id); 
       // echo "I am here".print_r($folder); 
        if ($folder->isValid()) {
		 
	        // 1st see if the user tried to import subscribers
	        if ($this->request->isPost()) {
				// See what action we are taking
                $actiontype = $this->request->getParam('actiontype');
                
                
                if ($actiontype == 'upload') {
                	if ($this->user->isSuperAdmin() || $this->session->canImport) {
	                    // initialize the uploader
	                    $uploader = new Application_Model_Upload;
	                    
	                    // get the action from post
	                    $upload = $this->request->getParam('upload');
	                    
	                    if ($upload == 'Upload File') {
	                        $upload_path = '../application/imports/';
	                        // set the upload directory
	                        $uploader->setUploadDir($upload_path);
	                        // give the valid file type extensions
	                        $uploader->setValidExt(array('csv'));
	                        
	                        // Give the filename some context
	                        $filename = $this->user->getId().'-'.$id.'-'.time().'.csv';
	                        
	                        // do the upload
	                        if (($result = $uploader->uploadFile($filename)) === true) {
	                            
	                            // Now open the file and import the subscribers
	                            ini_set('auto_detect_line_endings', TRUE); 
	                            if (($handle = fopen($upload_path.$filename, "rb")) !== false) {
	                                while(($subscriber = fgetcsv($handle, 0, "\n")) !== false) {
	                                    if (trim($subscriber[0])) {
	                                        if ($folder->addSubscriber($subscriber[0]) === false) {
	                                            $errors[] = $folder->getError();
	                                        }
	                                    }
	                                }
	                                fclose($handle);
	                                
	                                if (!empty($errors)) {
	                                    $error = $errors;
	                                } else {
	                                    $message = 'Subscribers imported!';
	                                }
	                            } else {
	                                $error = 'The file uploaded but could not be imported. Please contact us.';
	                            }
	                        } else {
	                            $error = $uploader->displayError();
	                        }
	                    }
                	} else {
                		$error = 'You do not have permission to carry out this operation';
                	}
                }
                
                if ($actiontype == 'movenumber') { 

                    $newfolderid = $this->request->getParam('movedropdown');
                    $keywordDetails = $folder->getKeywordDetailsByFolderId($newfolderid);
                    if(!empty($keywordDetails))
                        $newkeywordid = $keywordDetails[0]['id'];
                    else
                        $newkeywordid = 0;     
                                        
                    $subscriberidArray = $this->getRequest()->getParam('subscid'); 
                    foreach($subscriberidArray as $subscriberid)
                    {
                        $moveradioid = 'moveradio'.$subscriberid;
                        $moveORcopy = $this->request->getParam($moveradioid);
                        
                        if($moveORcopy == 'copy')
                        {
                            $subscriberDetails = $folder->getSubscriberDetailsById($subscriberid);
                            $newsubscriberid = $folder->copyPhoneNumber($newfolderid,$subscriberDetails[0]['phonenumber']);
                            if($newsubscriberid)
                            {
                                $message = "Phone number copied sucessfully";
                                //$this->_redirector->gotoUrl('/folder/view/id/'.$newfolderid); 
                            }                        
                        }elseif($moveORcopy == 'move')
                        {
                            if($folder->movePhoneNumber($subscriberid,$newfolderid,$newkeywordid))
                            {
                                $message = "Phone number moved sucessfully";
                                //$this->_redirector->gotoUrl('/folder/view/id/'.$newfolderid); 
                            }else{
                                $error = 'An error occurred and the phone number has not been moved';
                            }
                        }                       
                    }                                      
                    //echo "<pre>"; print_r($this->request); exit;
                }
	        }
                if ($this->request->getParam('actiontype') == 'optout') {
                	if ($this->user->isSuperAdmin() || $this->session->canImport) {
	                    $subscriber = $this->request->getParam('subscriber');
	                    
	                    if ($subscriber) {
	                        if ($folder->optOutSubscriberById($subscriber)) {
	                            $message = 'Subscriber opted out.';
	                        }
	                    }
                	} else {
                		$error = $error ? $error . "<br />" : '';
                		$error .= 'You do not have sufficient permission to opt out subscribers';
                	}
                }	  
				
	       $foldername  = $folder->name;
	        $folderid    = $folder->getId();
			
	        $subscribers = $folder->getSubscribersLatest(); //echo "<pre>"; print_r($subscribers); 
			
        } else {
        	$error = $folder->getError();
        }
        
        // View variables
        $this->view->foldername  = $foldername;
        $this->view->folderid    = $folderid;
        $this->view->subscribers = $subscribers;
        $this->view->error       = $error;
        $this->view->message     = $message;
        
        $this->view->folderList  = $folderList;
        
         //echo "<pre>"; print_r($this->view); 
		 //echo "I am here5555522";die;
		 //exit;
    }
   
    private function upload() {
    	
    }
    
    
    /*
    Combined folder/subscriber view logic. On hold for now.
    
    public function indexAction() {
    	$this->_forward('view');
    }
    public function viewAction() {
        // Defaults
        $error      = null;
    	$foldername = 'Not Found';
    	$folders    = array();
    	
    	$folderid = $this->request->getParam('id');
    	
    	// If there is a folder id try and get that folder
    	if ($folderid) {
	        $folder = new Application_Model_Folder($this->user, $folderid);
        	
	        if ($folder->isValid()) {
		        $foldername = $folder->name;
		        $folders    = $folder->getSubscribers();
	        } else {
	        	$error = $folder->getError();
	        }
        } else {
        	// otherwise show all folders
	        $user_locs = $this->user->getFolders();
	        
	        foreach ($user_locs as $id) {
	            $folders[] = new Application_Model_Folder($this->user, $id);
	        }
        }
        
        // View variables
        $this->view->folderid   = $folderid;
        $this->view->folders    = $folders;
	    $this->view->foldername = $foldername;
        $this->view->error      = $error;
    }*/
    
    public function editAction() {
    	// Defaults
    	$error      = null;
        $message    = null;
        $id = $this->request->getParam('id');
        
        $folderObj = new Application_Model_Folder($this->user, $id);        
            
            if ($this->request->isPost()) { 
                $folderDetail['id'] = $this->request->getParam('id'); 
                $folderDetail['name'] = trim($this->request->getParam('foldername'));

                if ($folderObj->updateFolderDetail($folderDetail)) {
	                            $message = 'Folder name updated.';
	                        }else{
                                    $error =  'Folder error: '.$folderObj->getError(); 
                            }
                $folderObj = new Application_Model_Folder($this->user, $id);             
               //$this->_redirector->gotoUrl('/folder/edit/id/'.$id);              
           }   
        $this->view->foldername = $folderObj->name;
        $this->view->folderid = $id;
        $this->view->error = $error;
        $this->view->message = $message;
    } 
    
    
     public function deleteAction() {
        $folderObj = new Application_Model_Folder($this->user);  
        $folderid = $this->request->getParam('id');
        //if ($this->user->isSuperAdmin() || $this->session->canImport) {
         $reportObj = new Application_Model_Report();
         if($reportObj->getTotalSubscriberByFolder($folderid) == 0)
         {
            if ($folderObj->deleteFolder($folderid)) {
                        $message = 'Folder Deleted.';
            }else{
                    $error =  'Folder error: '.$folderObj->getError(); 
            }             
          }else{
                $error = "Folder can not be deleted, it has subscriber(s)";
         }
        //}
        
        $this->view->error = $error;
        $this->view->message = $message;
        $this->_redirector->gotoUrl('/folder/'); 
     }
}

