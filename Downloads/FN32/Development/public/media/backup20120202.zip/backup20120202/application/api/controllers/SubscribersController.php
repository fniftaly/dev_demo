<?php
class Api_SubscribersController extends ApiControllerAbstract {
	public function indexAction() {
		$this->_notImplemented();
	}
	
	public function getAction() {
		$this->_notImplemented();
	}
	
	public function postAction() {
		//$this->_notImplemented();
        $authObj = new Application_Model_Auth(); 
        $isAuthorized = $authObj->authenticate($this->_requestParam('user'),$this->_requestParam('pass'));
        if($isAuthorized)
            $this->addSubscriber($isAuthorized);
        else
            $this->setError('You are not authorized to add subscriber.', 500);
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	
	public function deleteAction() {
		$this->_notImplemented();
	}
    
	public function addSubscriber($userid) {
		
		$phonenumber  = $this->_requestParam('phonenumber');
		$folder = $this->_requestParam('folder');
        //$keyword = $this->_requestParam('keyword');
		$firstname = $this->_requestParam('firstname');
		$lastname = $this->_requestParam('lastname');
		$email = $this->_requestParam('email');  
        $birthday = $this->_requestParam('birthday');  
        $language = $this->_requestParam('language');  
        
        if($phonenumber==''){
    		$this->setError('At least phone number is required.', 500);
    	}elseif($folder==''){
            $this->setError('At least your folder should be mentioned.', 500);
        }else{
                $folderObj = new Application_Model_Folder($this->apiuser);  
                $folderid = $folderObj->getFolderid_bynameuserid($folder,$userid);

                if($folderid){
                    $subscriberadded = $folderObj->addSubscriberAllDetails($folderid,$phonenumber,$firstname,$lastname,$email,$birthday,$language);

                    if ($subscriberadded) {
                        /*$this->setOutputParam('status', true);
                        $this->setOutputParam('message', 'Subscribers added sucessfully');*/
                        
                        $message     = new Application_Model_Message($this->apiuser);
                        $bodytext    = 'Hi! You have been registered under '.$folder.'. \nTo unsubscribe reply STOP 2quit.';
                        $subjecttext = $folder.': Enjoy our service';
                        $msg = $subjecttext ? $subjecttext.': '.$bodytext : $bodytext;
                        $return = $message->queue($msg, $phonenumber);

                        if ($return) {
                            $this->setOutputParam('status', true);
                            $this->setOutputParam('message', 'Subscribers added & message sent successfully.');
                        } else {
                            $this->setError($message->getError(), 500);
                        }                        
                        
                    } else { 
                        $this->setError($folderObj->getError(), 500);
                    }                      
                }else{
                        $this->setError('Folder Not Valid .', 500);
                }            
        }      
	}    
    
}
