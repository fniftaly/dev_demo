<?php
class Api_KeywordsController extends ApiControllerAbstract {
	public function indexAction() {
		$this->_notImplemented();
	}
	
	public function getAction() {
		if ($this->_requestId) {
			$keyword = new Application_Model_Keyword($this->_requestId);
			$this->setOutputParam('body', (array) $keyword);
		}
	}
	
	public function postAction() {
		$this->_notImplemented();
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
}
