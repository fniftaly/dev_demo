<?php
class Api_ErrorController extends ApiControllerAbstract {
	public function errorAction() {
		$errors = $this->_getParam('error_handler');
		$request = $errors->request->getParam('controller');
		
		switch ($errors->type) {
			case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ROUTE:
			case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER:
			case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION:
				// 404 error -- controller or action not found
				$this->getResponse()->setHttpResponseCode(404);
				//$this->view->message = 'Page not found so you stop look here';
				$this->_sendOutput(array('Error' => "Sorry, there is no $request API segment. Please check your request and try again."));
				break;
			
			default:
				// application error
				$this->getResponse()->setHttpResponseCode(500);
				//$this->view->message = 'Application error';
				$this->_sendOutput(array('Error' => 'Application error'));
		}
		
		//$this->view->exception = $errors->exception;
		//$this->view->request   = $errors->request;
	}
	
	public function indexAction() {
		$this->_notImplemented();
	}
	
	public function getAction() {
		$this->_notImplemented();
	}
	
	public function postAction() {
		$this->_notImplemented();
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
}
