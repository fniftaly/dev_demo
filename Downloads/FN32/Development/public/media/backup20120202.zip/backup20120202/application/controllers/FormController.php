<?php

class FormController extends AuthorizedController {
    
    /**
     * Redirector - defined for code completion
     *
     * @var Zend_Controller_Action_Helper_Redirector
     */
    protected $_redirector = null;
 
    public function init()
    {
        $this->_redirector = $this->_helper->getHelper('Redirector');              
    }    

    public function indexAction() {
        /*$tinyurl = new Zend_Service_ShortUrl_TinyUrlCom();
        echo $short = $tinyurl->shorten('http://www.textm.us/form/link/url/testurltext786'); echo "<br>";
        
        $tinyurl1 = new Zend_Service_ShortUrl_JdemCz();
        echo $short1 = $tinyurl1->shorten('http://www.textm.us/form/link/url/testurltext786'); echo "<br>";
        
        $tinyurl2 = new Zend_Service_ShortUrl_MetamarkNet();
        echo $short2 = $tinyurl2->shorten('http://www.textm.us/form/link/url/testurltext786'); echo "<br>";
        
        $tinyurl3 = new Zend_Service_ShortUrl_IsGd();
        echo $short3 = $tinyurl3->shorten('http://www.textm.us/form/link/url/testurltext786'); echo "<br>";
        
        exit;*/
    }    
    
    public function createAction() { 
        $error      = null;
        $message    = null;
        $userid = $this->user->getId();
        $username=$this->user->username();     
        $formObj = new Application_Model_Form();
        $reportObj =  new Application_Model_Report();
        if($reportObj->checkAdminUser($userid)){
            $subUsersArray = $reportObj->findChildEntityList($userid,5,"");  //echo "<pre>"; print_r($subUsersArray); exit;
            $webformListSubAccount = array();
            foreach($subUsersArray as $subuser){  
                $webformListSubAccount = array_merge($webformListSubAccount, $formObj->webformList($subuser['childuserid']));
            }        //echo "<pre>"; print_r($webformListSubAccount); exit;     
        }        
        
        if($this->request->isPost()){ //echo "<pre>"; print_r($this->_request->getParams()); exit;
            if($this->request->getParam('formurl') == ""){
                $message['type'] = "error";
                $message['body'] = "Atleast Unique URL is required";                      
            }else{ 
                    $createformfor = "";
                    if($this->request->getParam('subacc')=="on"){
                        $folderidArray = "subacc";                        
                    }else{
                        $folderidArray = $this->request->getParam('folderid');
                    }                
                
                    
                    if(!empty($folderidArray)){

                        $webformUrlArray = array();
                        $weburl = trim($this->request->getParam('formurl'));          
                        $weburlfilter = preg_replace('/[^a-z0-9]/', '-', $weburl);
                        
                        if($folderidArray == "subacc"){
                            foreach($subUsersArray as $subuser){  
                                $userid = $subuser['childuserid'];
                                $folderids = $this->user->getFolderElseCreate("weboptin",$userid);
                                $webformUrlArray = Array(
                                                            "entityid" => $userid,
                                                            "urlname" => addslashes($weburlfilter),
                                                            "thankumsg" => addslashes($this->request->getParam('thanku_message')),
                                                            "descmsg" => addslashes($this->request->getParam('formdesc')),
                                                            "folderid" => $folderids
                                                        );
                                $webformAttbArray = $this->request->getParam('chkname'); //echo "<pre>"; print_r($webformAttbArray); 
                                $webformAttbTypeArray = $this->request->getParam('chktype'); //echo "<pre>"; print_r($webformAttbTypeArray); 
                                $webformAttbWeightage = $this->request->getParam('weightage'); //echo "<pre>"; print_r($webformAttbTypeArray);

                                //echo "<pre>"; print_r($this->request->getParam('chk')); 
                                foreach($this->request->getParam('chk') as $key => $checked){  
                                    $webformAttbArrayToinsert[$key]['weightage'] = addslashes($webformAttbWeightage[$checked]);
                                    $webformAttbArrayToinsert[$key]['attb'] = addslashes($webformAttbArray[$checked]);
                                    $webformAttbArrayToinsert[$key]['attbtype'] = addslashes($webformAttbTypeArray[$checked]);
                                    $webformAttbOptionArray = $this->request->getParam('chkvalue'.$checked); //echo "<pre>"; print_r($webformAttbOptionArray);
                                    if(!empty($webformAttbOptionArray)){
                                        $webformAttbOptionString = implode(",",$webformAttbOptionArray);
                                    }else{
                                        $webformAttbOptionString = "";
                                    }

                                    $webformAttbArrayToinsert[$key]['attboption'] = addslashes($webformAttbOptionString);
                                }      //echo "<pre>"; print_r($webformAttbArrayToinsert);   exit; 
                                if(empty($webformAttbArrayToinsert)){
                                    $message['type'] = "error";
                                    $message['body'] = "Please check atleast one information field";                          
                                }elseif(empty($folderidArray)){
                                    $message['type'] = "error";
                                    $message['body'] = "Please choose atleast one folder";                            
                                }else{
                                        $dataInserted = $formObj->insertFormDetails($webformUrlArray, $webformAttbArrayToinsert);
                                        if($dataInserted){
                                            $message['type'] = "success";
                                            $message['body'] = "Form created successfully";
                                        }else{ 
                                            $message['type'] = "error";
                                            $message['body'] = $formObj->getError();               
                                        }                         
                                }                               
                            }      
                            $this->_redirector->gotoUrl('/form/create/');
                        }else{
                                $folderids = implode($folderidArray,',');
                                $webformUrlArray = Array(
                                                            "entityid" => $userid,
                                                            "urlname" => addslashes($weburlfilter),
                                                            "thankumsg" => addslashes($this->request->getParam('thanku_message')),
                                                            "descmsg" => addslashes($this->request->getParam('formdesc')),
                                                            "folderid" => $folderids
                                                        );
                                $webformAttbArray = $this->request->getParam('chkname'); //echo "<pre>"; print_r($webformAttbArray); 
                                $webformAttbTypeArray = $this->request->getParam('chktype'); //echo "<pre>"; print_r($webformAttbTypeArray); 
                                $webformAttbWeightage = $this->request->getParam('weightage'); //echo "<pre>"; print_r($webformAttbTypeArray);

                                //echo "<pre>"; print_r($this->request->getParam('chk')); 
                                foreach($this->request->getParam('chk') as $key => $checked){  
                                    $webformAttbArrayToinsert[$key]['weightage'] = addslashes($webformAttbWeightage[$checked]);
                                    $webformAttbArrayToinsert[$key]['attb'] = addslashes($webformAttbArray[$checked]);
                                    $webformAttbArrayToinsert[$key]['attbtype'] = addslashes($webformAttbTypeArray[$checked]);
                                    $webformAttbOptionArray = $this->request->getParam('chkvalue'.$checked); //echo "<pre>"; print_r($webformAttbOptionArray);
                                    if(!empty($webformAttbOptionArray)){
                                        $webformAttbOptionString = implode(",",$webformAttbOptionArray);
                                    }else{
                                        $webformAttbOptionString = "";
                                    }

                                    $webformAttbArrayToinsert[$key]['attboption'] = addslashes($webformAttbOptionString);
                                }      //echo "<pre>"; print_r($webformAttbArrayToinsert);   exit;
                                if(empty($webformAttbArrayToinsert)){
                                    $message['type'] = "error";
                                    $message['body'] = "Please check atleast one information field";                          
                                }elseif(empty($folderidArray)){
                                    $message['type'] = "error";
                                    $message['body'] = "Please choose atleast one folder";                            
                                }else{
                                        $dataInserted = $formObj->insertFormDetails($webformUrlArray, $webformAttbArrayToinsert);
                                        if($dataInserted){
                                            $message['type'] = "success";
                                            $message['body'] = "Form created successfully";
                                        }else{ 
                                            $message['type'] = "error";
                                            $message['body'] = $formObj->getError();               
                                        }                         
                                }                                 
                        }                                                                      
                    }else{
                            $message['type'] = "error";
                            $message['body'] = "Please select atleast one folder from dropdown.";                         
                    }                     
            }                
        } 
        $this->view->message = $message;
        $this->view->folders  = $this->user->getFolders(); 
        $this->view->webformlist = $formObj->webformList($userid);
        $this->view->webformlistSubaccount = $webformListSubAccount;

    }  
    
    public function linkAction() {

        $this->_helper->layout->setLayout('formlayout');
        $formObj = new Application_Model_Form();
        $error = array();
        $success = array();
        
        $formlink = explode('text',$this->request->getParam('url'));
        $formurl = $formlink['0'];
        $userid = $formlink['1'];
        
        $formObj = new Application_Model_Form();
        $webformattb = $formObj->webformDetail($userid,addslashes($formurl));  //echo "<pre>"; print_r($webformattb); exit;
        if(empty($webformattb)){
            $message['type'] = "error";
            $message['body'] = "Form doesn't exist";             
        }else 
            $this->view->webformattb = $webformattb;
        
        if($this->request->isPost()){
           $postdataValue = $this->_request->getParams(); 
           //$otherpostData = array("controller","action","url","module","0");
           /*$dataSubscriberTable = array(
                                        'webform_url_id'=>$webformattb['0']['webform_url_id'],
                                        'phonenumber' => $postdataValue[0],
                                        'firstname'=>'',
                                        'lastname'=>'',
                                        'birthday'=>'',
                                        'language'=>''
                                       );*/
           $webform_url_id = $webformattb['0']['webform_url_id'];
           $phonenumber = $postdataValue[0];
           $firstname = "";
           $lastname = "";
           $email = "";
           $birthday = "";
           $language = "";
           $folderidArray = explode(",",$webformattb['0']['folderid']);
           
           unset($postdataValue['controller'],  $postdataValue['action'],  $postdataValue['url'],  $postdataValue['module'],  $postdataValue['accept']);
        
           if($this->request->getParam('accept')==1){
               if(!empty($postdataValue[0])){
                   
                  unset($postdataValue['0']); 
                  foreach($postdataValue as $attbid => $attbvalue){
                       $attbnameArray = $formObj->getAttributeName($attbid); 
                       $attbnam = $attbnameArray['0']['attribute']; 

                       if($attbnam == "Email"){
                           $email = addslashes($postdataValue[$attbid]); //$dataSubscriberTable['email'] = $postdataValue[$attbid];
                           unset($postdataValue[$attbid]);
                       }elseif($attbnam == "First Name"){
                           $firstname = addslashes($postdataValue[$attbid]); //$dataSubscriberTable['firstname'] = $postdataValue[$attbid];
                           unset($postdataValue[$attbid]);
                       }elseif($attbnam == "Last Name"){
                           $lastname = addslashes($postdataValue[$attbid]); //$dataSubscriberTable['lastname'] = $postdataValue[$attbid];
                           unset($postdataValue[$attbid]);
                       }elseif($attbnam == "Birth Day"){ 
                           $attbvalue = implode("-", $postdataValue[$attbid]);
                           $birthday = $attbvalue; //$dataSubscriberTable['birthday'] = $postdataValue[$attbid];
                           unset($postdataValue[$attbid]);
                       }elseif($attbnam == "Language"){ 
                           $language = addslashes($postdataValue[$attbid]); //$dataSubscriberTable['birthday'] = $postdataValue[$attbid];
                           unset($postdataValue[$attbid]);
                       } 
                  } 
                  //echo "<pre>"; print_r($postdataValue); exit;
                  $s=0; $a=0; $attbidArray = array();
                  foreach($folderidArray as $folderid){ 
                      if(count($formObj->getSubscriber($phonenumber,$folderid))==0){
                         $subscriberid[$s] = $formObj->addSubscriberAllDetails($folderid,$phonenumber,$firstname,$lastname,$email,$birthday,$language,$webform_url_id);  
                         $s++;
                      }else{
                          $error[1] = "Phone number: $phonenumber has already been subsrcribed to folder: $folderid";
                      }
                  }  
                  foreach($postdataValue as $attbid => $attbvalue){                       
                     if(is_array($attbvalue)){
                          $attbvalueins[$a] = implode(",", $attbvalue);
                          $attbvalueins[$a] = addslashes($attbvalueins[$a]);
                          $attbidArray[$a] = $attbid;
                          $a++;
                          foreach($attbvalue as $folderid){
                              if(count($formObj->getSubscriber($phonenumber,$folderid))==0)
                                    $subscriberid[$s] = $formObj->addSubscriberAllDetails($folderid,$phonenumber,$firstname,$lastname,$email,$birthday,$language,$webform_url_id);
                                    $s++;
                          }
                     }else{ 
                            $attbvalueins[$a] = addslashes($attbvalue);
                            $attbidArray[$a] = $attbid;
                            $a++;
                            if(count($formObj->getSubscriber($phonenumber,$attbvalue))==0)
                                $subscriberid[$s] = $formObj->addSubscriberAllDetails($attbvalue,$phonenumber,$firstname,$lastname,$email,$birthday,$language,$webform_url_id);   
                                $s++;
                     }                  
                  } 
                  for($i=0;$i<$s;$i++){
                      for($j=0;$j<$a;$j++){
                          $formObj->insertFormValues($subscriberid[$i],$attbidArray[$j], $attbvalueins[$j]);
                      }
                  }                                                     
                  $success[0] = $webformattb['0']['thankumsg'];   
                  $msgObj = new Application_Model_Message();
                  $status = $msgObj->queue($webformattb['0']['thankumsg'], $phonenumber, "", "");
                  /*foreach($folderidArray as $folderid){ 
                      if(count($formObj->getSubscriber($phonenumber,$folderid))==0){
                         $subscriberid = $formObj->addSubscriberAllDetails($folderid,$phonenumber,$firstname,$lastname,$email,$birthday,$language,$webform_url_id);
                         if($subscriberid){ //echo $subscriberid; echo "<pre>"; print_r($postdataValue); exit;
                           foreach($postdataValue as $attbid => $attbvalue){                                      
                              if(is_array($attbvalue)){
                                  $attbvalue = implode(",", $attbvalue);
                              }
                              $attbvalue = addslashes($attbvalue);
                              $formObj->insertFormValues($subscriberid,$attbid, $attbvalue);
                           } 
                          $success[0] = $webformattb['0']['thankumsg'];   
                         }else{
                             $error[0] = "Phone number: $phonenumber can not be added to folder: $folderid";
                         }                                                         
                      }else{
                          $error[1] = "Phone number: $phonenumber has already been subsrcribed to folder: $folderid";
                      }
                  }*/                 
               }else{
                        $error[2] = "Phone number is required.";
               }                
           }else{
                    $error[3] = "Please accept the terms & conditions";
           }            
        }
        $this->view->success = $success;
        $this->view->error = $error;
    }      
    
    public function editAction() {
        $webformurlid = $this->request->getParam('id');
        if($webformurlid){
            $formObj = new Application_Model_Form();
            $webformadetails = $formObj->getWebformDeatils($webformurlid);
            if(count($webformadetails)==0){
                $this->_redirector->gotoUrl('/form/create/');
            }
            $attbArray = array();
            $userid = $webformadetails['0']['entityid'];
            
            foreach($webformadetails as $key => $webArray){ 
                $attbArray[$key] = $webArray['attribute'];
                $attbWeightage[$webArray['attribute']] =  $webArray['weightage'];
                $attbtoArray[$key]['attbtype'] = $webArray['attbtype'];
                $attbtoArray[$key]['attboption'] = $webArray['attboption'];
            }
            $this->view->webformadetails = $webformadetails;
            $this->view->attbarray = $attbArray; 
            $this->view->attbWeightage = $attbWeightage;
            $this->view->attbtoArray = $attbtoArray;
            $this->view->folders  = $this->user->getFolders(); 
            
            if($this->request->isPost()){
                if($this->request->getParam('formurl') == ""){
                    $message['type'] = "error";
                    $message['body'] = "Atleast Unique URL is required";                      
                }else{
                        $folderidArray = $this->request->getParam('folderid');
                        if(!empty($folderidArray)){
                            $folderids = implode($folderidArray,',');
                            $webformUrlArray = array();

                            $webformUrlArray = Array(
                                                        "entityid" => $userid,
                                                        "urlname" => addslashes(trim($this->request->getParam('formurl'))),
                                                        "thankumsg" => addslashes($this->request->getParam('thanku_message')),
                                                        "descmsg" => addslashes(($this->request->getParam('formdesc'))),
                                                        "folderid" => $folderids
                                                    );
                            $webformAttbArray = $this->request->getParam('chkname'); //echo "<pre>"; print_r($webformAttbArray);
                            $webformAttbTypeArray = $this->request->getParam('chktype'); //echo "<pre>"; print_r($webformAttbTypeArray);
                            //$webformAttbOptionArray = $this->request->getParam('chkvalue');  //echo "<pre>"; print_r($webformAttbOptionArray);  
                            $webformAttbWeightage = $this->request->getParam('weightage'); //echo "<pre>"; print_r($webformAttbTypeArray);                
                            //echo "<pre>"; print_r($this->request->getParam('chk')); exit;
                            foreach($this->request->getParam('chk') as $key => $checked){
                                $webformAttbArrayToinsert[$key]['weightage'] = addslashes($webformAttbWeightage[$checked]);
                                $webformAttbArrayToinsert[$key]['attb'] = addslashes($webformAttbArray[$checked]);
                                $webformAttbArrayToinsert[$key]['attbtype'] = addslashes($webformAttbTypeArray[$checked]);
                                //$webformAttbArrayToinsert[$key]['attboption'] = addslashes($webformAttbOptionArray[$checked]);  
                                $webformAttbOptionArray = $this->request->getParam('chkvalue'.$checked); //echo "<pre>"; print_r($webformAttbOptionArray);
                                if(!empty($webformAttbOptionArray)){
                                    $webformAttbOptionString = implode(",",$webformAttbOptionArray);
                                }else{
                                    $webformAttbOptionString = "";
                                }
                                $webformAttbArrayToinsert[$key]['attboption'] = addslashes($webformAttbOptionString);                            
                            }    //echo "<pre>"; print_r($webformAttbArrayToinsert); exit;        
                            if(empty($webformAttbArrayToinsert)){
                                $message['type'] = "error";
                                $message['body'] = "Please check atleast one information field";                          
                            }elseif(empty($folderidArray)){
                                $message['type'] = "error";
                                $message['body'] = "Please choose atleast one folder";                            
                            }else{                              
                                    $updateformURL = $formObj->updateFormURL($webformurlid,$webformUrlArray['thankumsg'],$webformUrlArray['descmsg'],$webformUrlArray['folderid']);
                                    $removeExistingAttb = $formObj->removeFormAttribute($webformurlid);
                                    if($removeExistingAttb){
                                        $addformURLAttribute = $formObj->addFormAttribute($webformurlid,$webformAttbArrayToinsert);
                                    }                               
                                    $this->_redirector->gotoUrl('/form/create/');                                                       
                            }                                
                        }else{
                            $message['type'] = "error";
                            $message['body'] = "Please select atleast one folder from dropdown.";                         
                        }            
                }                
            }             
            
        }else{
                $this->_redirector->gotoUrl('/form/create/'); 
        }
    }
    
    public function deleteAction(){
        //echo "<pre>"; print_r($this->_request->getParams()); exit;   
        $formObj = new Application_Model_Form();
        $deleteidArray = $this->request->getParam('deleteid');
        foreach($deleteidArray as $formid){ //echo $formid; exit;
            $formObj->deleteWebformById($formid); 
        }
        $this->_redirector->gotoUrl('/form/create/');
    }
    
    
}

