<?php
/**
 * Application_Model_Folder class.
 * 
 * Contains methods that are specific to the Folder Entity type.
 * 
 * @extends Application_Model_Entityabstract
 */
class Application_Model_Folder extends Application_Model_Entityabstract {
    /**
     * Folder type
     * 
     * @access protected
     * @var string
     */
    protected $_type = 'folder';
    
    /**
     * This is the field that will be checked for to already exist in entity meta for 
     * this entity type. This will prevent duplicate entity's, in a way, kinda. Need to
     * really look at this problem and figure out the best solution. TODO: read back.
     * 
     * @access protected
     * @var string
     */
    protected $_checkfield = 'name';
    
    /**
     * Subscriber list for this location.
     * 
     * (default value: array())
     * 
     * @var array
     * @access protected
     */
    protected $subscribers = array();
    
    /**
     * Parent ID of this folder, if there is one.
     * 
     * @var mixed
     * @access protected
     */
    protected $parentid;
    
    /**
     * Array of Children Folders of this folder
     * 
     * @var array
     * @access protected
     */
    protected $children = array();
    
    private $fetched_subscribers = false;
    
    /**
     * Update a folder meta data.
     *
     * @param array $meta Key=>Pair values for location meta data
     * @return bool Status of the update
     */
    public function update(array $meta) {
        // I think this will be moved to Entityabstract.
        // Update each field individually? Or require the API user
        // to send all params and just update all at once?
        
        return true;
    }
    
    /**
     * Checks if a folder already exists
     */
    public function folderExists($name) {
        return $this->loadEntityBy($this->_checkfield, $name);
    }
    
    /**
     * Return the current status of this location.
     * 
     * @access public
     * @return int Current status id of this location.
     */
    public function getStatus($verbose = true) {
        if ($verbose) {
            $types = $this->getStatusTypes();
            
            foreach ($types as $type) {
                if ($type['id'] == $this->status) return $type['name'];
            }
        }
        
        return $this->status;
    }
    
    /**
     * Returns an array of subscribers to this folder.
     * 
     * @access public
     * @return array Subscriber list
     */
    public function getSubscribers($forcenew = false) {
        // If we already got the subscribers, dont get them again unless forced to
        if ($forcenew || !$this->fetched_subscribers) {
	        $sql = "CALL folder_get_subscribers({$this->id})";
	        $rs = $this->query($sql);
	        
	        if ($this->hasError()) {
	           $this->setError("Could not get subscriber list for entity {$this->id}.", $this->getError());
	           return false;
	        }
	        
	        $this->fetched_subscribers = true;
	        
	        $this->subscribers = $rs->fetchAll();
        }
        
        return $this->subscribers;
    }
    
    /**
     * Returns an array of subscribers to this folder. Both Opted In & Opted Out
     * 
     * @access public
     * @return array Subscriber list
     */
    public function getSubscribersBothInOut($forcenew = false) { 
        // If we already got the subscribers, dont get them again unless forced to
        if ($forcenew || !$this->fetched_subscribers) { 
	        $sql = "CALL folder_get_subscribers_inout({$this->id})";
	        $rs = $this->query($sql); //echo "<pre>"; print_r($rs); exit;
	        
	        if ($this->hasError()) {
	           $this->setError("Could not get subscriber list for entity {$this->id}.", $this->getError());
	           return false;
	        }
	        
	        $this->fetched_subscribers = true;
	        
	        $this->subscribers = $rs->fetchAll(); 
        }
        
        return $this->subscribers;
    }    
    
    public function getSubscribersLatest($forcenew = false) { 
        // Get the latest subscribers that had opted in to a particular folder
        if ($forcenew || !$this->fetched_subscribers) { 
	        $sql = "CALL folder_get_subscribers_latest({$this->id})";
	        $rs = $this->query($sql); //echo "<pre>"; print_r($rs); exit;
	        
	        if ($this->hasError()) {
	           $this->setError("Could not get subscriber list for entity {$this->id}.", $this->getError());
	           return false;
	        }
	        
	        $this->fetched_subscribers = true;
	        
	        $this->subscribers = $rs->fetchAll(); 
        }
        
        return $this->subscribers;
    }     
    
    /**
     * Returns the # of subscribers in this folder.
     * 
     * @access public
     * @return void
     */
    public function subscriberCount() {
    	return count($this->getSubscribers());
    }
    
    /**
     * Add a subscriber to this folder.
     * 
     * @access public
     * @param mixed $subscriberid
     * @return void
     */
    public function addSubscriber($phonenumber) {
        /*$sql = "CALL folder_add_subscriber({$this->id}, {$subscriberid})";
        $rs = $this->query($sql);
        
        if ($this->hasError()) {
           $this->setError('Could not add subscriber to location.', $this->getError());
           return false;
        }
        
        return true;*/
        
        // Reset the error holder. Not sure if this is the best way to do this, but I don't want 
        // the model thinking it has an error on this add when there was an error on the last add.
        $this->error = false;
        
        // Will be populated with any subscriber phonenumbers already in this folder
        //$existing = array();
        
        // save the original input
        $orig_input = $phonenumber;
        
        // This will get the current subscriber list, which will not return opted out
        // subscribers. This way if a subscriber opts out, then opts back in, they will
        // get a new entry in the subscriber list for this folder. I think this logic
        // works well, but maybe we need to discuss. TODO: discuss
        /*foreach ($this->getSubscribers(true) as $sub) {
       	    $existing[] = $sub['phonenumber'];
        }*/
        
        // Clense the phonenumber
        $phonenumber = $this->cleanPhone($phonenumber);
        
        if (empty($phonenumber)) {
            return null;
        }
        
        if (strlen($phonenumber) < 10) {
            $this->setError('Invalid phonenumber "'.$orig_input.'" not imported."');
            return false;
        }
        
        // TODO: can delete the above proc from the db once this new method is confirmed better
        $sql = "CALL subscriber_add_to_folder({$this->id}, $phonenumber)";
        $rs  = $this->query($sql);
        
        if ($this->hasError()) {
            $error = 'Could not add subscriber: "'.$orig_input.'", filtered to: "'.$phonenumber.'" to Folder.';
            $this->setError($error, $error.' - '.$sql.': '.$this->getError());
           	return false;
        }
        
        if ($rs->id < 0) {
       	    $this->setError('Subscriber ['.$phonenumber.'] already in this folder.');
       	    return false;
        }
        
        return $rs->id;
    }
    
    public function cleanPhone($phonenumber) {
        return preg_replace("/[^0-9]/", "", $phonenumber);
    }
    
    /**
     * Add an array of subscribers in this folder.
     * 
     * @access public
     * @param array $subscribers
     * @return void
     */
    public function addSubscribers(array $subscribers) {
        $errors  = array();
        $success = array();
        
        foreach ($subscribers as $subscriber) {
            $add = $this->addSubscriber($subscriber);
            var_dump($add); die;
            if ($add) {
                $success = $add->id;
            } else {
                // Add to the error array the id and error
                $fail = array();
                $fail['id']    = $subscriber;
                $fail['error'] = $this->error;
                $error[] = $fail;
            }
        }
        
        if (!empty($error)) {
            $this->error = $error;
        }
        
        return $success;
    }
    
    
    public function getFolderid($foldername){
		if ($foldername) {
            
			$sql = "CALL get_folderid_from_name('$foldername')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->folderid) {
                    return $rs->folderid;
                }
            }

		}
		return NULL;                
    }
    
    public function getFolderid_bynameuserid($foldername,$userid){
		if ($foldername) {
            
			$sql = "CALL get_folderid_from_nameuserid('$foldername',$userid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                if ($rs->folderid) {
                    return $rs->folderid;
                }
            }

		}
		return NULL;                
    }    
    
    
    public function addSubscriberAllDetails($folderid,$phonenumber,$fname,$lname,$emailid,$bday,$lang,$webformid=null) {

        $this->error = false;
        $orig_input = $phonenumber;        
        
        // Clense the phonenumber
        $phonenumber = $this->cleanPhone($phonenumber);
        
        if (empty($phonenumber)) {
            return null;
        }
        
        if (strlen($phonenumber) < 10) {
            $this->setError('Invalid phonenumber "'.$orig_input.'" not added."');
            return false;
        }
        if($webformid)
               $sql = "CALL subscriber_add_with_metadata_webform($folderid, '$phonenumber', '$fname', '$lname', '$emailid', '$bday', '$lang','webform',$webformid)";
            else
                $sql = "CALL subscriber_add_with_metadata($folderid, '$phonenumber', '$fname', '$lname', '$emailid', '$bday', '$lang')";
            
        $rs  = $this->query($sql);
         
        if ($this->hasError()) {
            $error = 'Could not add subscriber: "'.$orig_input.'", filtered to: "'.$phonenumber.'" to Folder.';
            $this->setError($error, $error.' - '.$sql.': '.$this->getError());
           	return false;
        }
        
        if ($rs->id < 0) {
       	    $this->setError('Subscriber ['.$phonenumber.'] already in this folder.');
       	    return false;
        }
        
        return $rs->id;
    }
    
    
    /**
     * Add another folder to this folder. This folder becomes the parent
     * and the added folder becomes a child.
     * 
     * @access public
     * @return void
     */
    /*public function add() {
    	return true;
    }*/
    
    /**
     * Retrieves messages sent for this location.
     * 
     * @access public
     * @param int $start Start record to return
     * @param int $stop Stop record to return
     * @return array
     */
    public function getMessages($start = 0, $stop = 50) {
    	$sql = "CALL folder_get_messages({$this->id},{$start},{$stop})";
    	$rs  = $this->query($sql);
    	
    	if ($this->hasError()) {
    		$this->setError('Could not retrieve location messages. Reason: '.$this->getError());
    		return false;
    	}
    	
    	return $rs->fetchAll();
    }
    
    /**
     * Opts a subscriber out of a folder by phonenumber
     * 
     * @param string $phonenumber
     * @return boolean
     */
    public function optOutSubscriber($phonenumber) {
    	if ($this->id) {
			$phonenumber = $this->cleanPhone($phonenumber);
            
            $this->_getDBH();
            $phonenumber = $this->_dbh->real_escape_string($phonenumber);
            
            $sql = "CALL folder_delete_subscriber($this->id, $phone)";
			$rs = $this->query($sql);
			return $rs->success > 0;
		}
		
		return false;
    }
    
    /**
     * Opts a subscriber out of a folder by subscriber id
     * 
     * @param string $phone
     * @return boolean
     */
    public function optOutSubscriberById($id) {
    	if ($this->id) {
            $sql = "CALL folder_delete_subscriber_by_id($this->id, $id)";
			$rs = $this->query($sql);
			return $rs->success > 0;
		}
		
		return false;
    }   
    
    public function updateFolderDetail($folderDetailArray){ 
        $folderid = $folderDetailArray['id'];
        $foldername = $folderDetailArray['name'];
        $sql = "CALL folder_update_details($folderid,'$foldername')";
        $rs = $this->query($sql); 
        if ($rs && $rs->num_rows) {
            if ($rs->success !== null){
                if ($rs->success >= 1){
                    return true;
                }else{
                        $this->error = 'An error occurred and the folder name changes could not be saved';
                }
           }else{
                    $this->error = 'An error occurred and the folder name could not be saved';
            }
       }
    }
    
    public function getSubscriberDetailsById($subscriberid) {
        if ($subscriberid) { 
            $sql = "CALL folder_get_subscribers_byid($subscriberid)";
            $rs  = $this->query($sql); 
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }
    
    public function getKeywordDetailsByFolderId($folderid) {
        if ($folderid) { 
            $sql = "CALL keyword_get_byfolderid($folderid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll();
            }

		}
		return NULL;
    }    
    
    public function movePhoneNumber($subscriptionid,$newfolderid,$newkeywordid){ 
        if($subscriptionid!=0 AND $subscriptionid!='')
        { 
            $sql = "CALL folder_subscriber_update_folderid_keywordid($subscriptionid,$newfolderid,$newkeywordid)";
            $rs = $this->query($sql);
                    if ($rs->success >= 1){
                        return true;
                    }else{
                            $this->error = 'An error occurred and the phone number has not been moved';
                    }            
        }
    }   
    
    public function copyPhoneNumber($newfolderid,$phonenumber){
        if($phonenumber)
        { 
            $sql = "CALL subscriber_add_to_folder($newfolderid,$phonenumber)";
            $rs  = $this->query($sql); 

            if ($this->hasError()) {
                $error = 'Could not add subscriber: "'.$phonenumber.'", filtered to: "'.$phonenumber.'" to Folder.';
                $this->setError($error, $error.' - '.$sql.': '.$this->getError());
                return false;
            }

            if ($rs->id < 0) {
                $this->setError('Subscriber ['.$phonenumber.'] already in this folder.');
                return false;
            }

            return $rs->id;       
            }
    }  
    
    public function deleteFolder($id) {
    	if ($id) {
            $sql = "CALL folder_delete_byid($id)";
			$rs = $this->query($sql);
			if($rs->success > 0)
                return true;
            else
                $this->error = "An error occurred while deleting folder";
                
		}
		
		return false;
    }  
    
    public function getFoldersByPhoneNumber($iphonenumber){
        if($iphonenumber){
            $sql = "CALL get_folderids_byphonenumber($iphonenumber)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll(); 
            }
        }
        
        return false;
    }
    
    public function getFoldersByfolderidstring($folderidstr){
        if($folderidstr){ 
            $userid = $this->user->getId(); 
            $sql = "CALL user_get_folders_byidstring($userid,'$folderidstr')";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll(); 
            }
        }
        
        return false;
    }    
    
    public function getPhoneNumberOptinoutDate($phonenumber,$folderid){
            $sql = "CALL get_phonenumber_optinoutdate($phonenumber,$folderid)";
            $rs  = $this->query($sql);
            if ($rs->hasRecords()) {
                    return $rs->fetchAll(); 
            }else{
                return false;
            }
    }
    
}
