<?php
/**
 * Application_Model_Faqs class.
 * 
 * Manage Frequently Asked Questions Content
 * 
 * @extends Application_Model_Abstract
 */
class Application_Model_Faqs extends Application_Model_Abstract {
    /**
     * Retrieves all FAQs.
     * 
     * @access public
     * @return array
     */
    public function get($active_only = true) {
    	$active_only = (bool) $active_only;
        $sql = "CALL faqs_get({$active_only})";
    	$rs  = $this->query($sql);
    	
    	if ($this->hasError()) {
    		$this->setError('Could not retrieve FAQs');
    		return false;
    	}
    	
    	return $rs->fetchAll();
    }
    
    /**
     * Update a folder meta data.
     *
     * @param 
     * @return bool Status of the update
     */
    public function update($id,$title,$content,$active) {
        $title   = $this->_dbh->real_escape_string($title);
        $content = $this->_dbh->real_escape_string($content);
        
        if (empty($title)) {
            $this->setError('Title is required');
            return false;
        }
        if (empty($content)) {
            $this->setError('Content is required');
            return false;
        }
        
        $sql = "CALL faq_update({$id},'{$title}','{$content}',{$active})";
        $rs = $this->query($sql);
        
        if ($this->hasError()) {
           $this->setError("Could not update FAQ", $this->getError());
           return false;
        }
        
        return true;
    }
    
    /**
     * Insert a new FAQ entry
     *
     * @return bool
     */
    public function add($title,$content,$active = 1) {
        $title   = $this->_dbh->real_escape_string($title);
        $content = $this->_dbh->real_escape_string($content);
        
        if (empty($title)) {
            $this->setError('Title is required');
            return false;
        }
        if (empty($content)) {
            $this->setError('Content is required');
            return false;
        }
        
        $sql = "CALL faq_add('{$title}','{$content}',$active)";
        $rs = $this->query($sql);
        
        if ($this->hasError()) {
           $this->setError("Could not update FAQ", $this->getError());
           return false;
        }
        
        return true;
    }
    
    
}
