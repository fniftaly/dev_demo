<?php

class UsersController extends AuthorizedController {
    /**
	 * This page is only accessable by admins.
	 * 
	 * @access public
	 */
	public function preDispatch() {
		parent::preDispatch();
        
        // See if we have a logged in user.
	    if (isset($this->user) && $this->user instanceof Application_Model_User && !$this->user->isAdmin()) {
	    	$this->_redirect('/');
	    }
	}
	
	public function testAction() {
		var_dump($this->session->getDatastore());
	}
	
    /**
     * Index page lists all system users.
     * 
     * @access public
     */
    public function indexAction() {
	
    	// Get all users this user is a parent of
    	$this->view->users = $this->user->getUsers();
        
        if ($this->request->isPost()) {
        	// See if they are switching into another user
            $actiontype = $this->request->getParam('actiontype');
            
            if ($actiontype == 'switchuser') {
            	// Get the switch users id
                $switchuser = (int) $this->request->getParam('switchuser');
                
                // Build the switch user to see if it is a valid id
                $user = new Application_Model_User($switchuser);
                
                if ($user->isValid()) {
                    // Only switch into users the current user is a parent of
                    if ($this->user->isSuperAdmin() || $this->user->isParentOf($switchuser)) {
	                    // change the session info to have the new user
	                    $this->session->asUser($switchuser);
	                    $this->session->lastUser($this->user->getId());
	                    // This is here so admins can log into their customers accounts
	                    // and import numbers for them, as regular users are not allowed
	                    // to import. Probably can figure out a better way to handle this.
	                    $this->session->canImport = true;
	                    $this->session->isAdmin   = true;
	                    // direct to the dashboard
	                    $this->_redirect('/');
                    }
                }
            }
        }
    }
    
    /**
     * Add a new user.
     * 
     * @access public
     */
    public function addAction() {
    	// Defaults
    	$error  = null;
    	$status = null;
    	
    	$entity = new Application_Model_Userentity($this->user);
    	
    	$users = $entity->getAll();
    	
    	if ($this->request->isPost()) {
	    	// Check our post array
			$post = $this->request->getPost();
			
			if (!empty($post)) {
				if ($entity->exists('user','username',$post['username'])) {
					$status = false;
					$error  = 'Username already taken.';
				} else {
					// Special handling for passwords
					if (array_key_exists('password', $post)) {
		                // Use a special method for updating passwords
		                $post['password'] = $entity->encryptPassword($post['password']);
		            }
		            
		    		// Add the entity with all of the passed info
		    		$entity->addWithMeta($post);
	    			
		    		$status = $entity->isValid();
		    		$error  = $entity->getError();
		    	}
			} else {
				$error = 'No data was presented to create the user with.';
			}
		}
		
		$this->view->status_types = $this->user->getStatusTypes();
		
		$this->view->error  = $error;
		$this->view->status = $status;
    }
    
    /**
     * Edit a passed user id.
     * 
     * @access public
     */
    public function editAction() {
    	// Defaults
    	$error  = null;
    	$status = null;
    	$user   = null;
    	$password_default = '*****';
    	
    	$userid = (int) $this->request->getParam('id');
    	
    	if ($userid) {
    		
	    	if ($this->request->isPost()) {
	    		// Build the user entity model so we can update values
	    		$entity = new Application_Model_Userentity($this->user, $userid);
	    		
	    		if ($entity->isValid()) {
	    			$new_values = $this->request->getPost();
	    			
	    			// dont allow duplicate usernames if they are changing the username
                    if ($new_values['username'] != $entity->username && $entity->exists('user','username',$new_values['username'])) {
						$status = false;
						$error  = 'Username already taken.';
					} else {
		    			if (array_key_exists('password', $new_values)) {
		    				if ($new_values['password'] != $password_default) {
		    					// Use a special method for updating passwords
		    					$entity->updatePassword($new_values['password']);
		    				}
		    				// Dont send this to the update method
		    				unset($new_values['password']);
		    			}
		    			
		    			// Handle the isadmin checkbox
		    			if (!array_key_exists('admin', $new_values)) {
		    				$new_values['admin'] = '';
		    			}
		    			
		    			// Handle the canimport checkbox
		    			// REMOVED PER JJ 2011-09-14 - rgonzale
		    			//if (!array_key_exists('canimport', $new_values)) {
		    			//	$new_values['canimport'] = '';
		    			//}
		    			
		    			// Update the meta values
			    		if ($entity->updateMetaValues($new_values)) {
			    			$status = true;
			    		} else {
			    			$error = $entity->getError();
			    		}
		    		}
	    		} else {
	    			$error = $entity->getError();
	    		}
	    	}
	    	
	    	// Get the user's model with the current field values
    		$user = new Application_Model_User((int) $userid);
    	} else {
    		$error = 'No User select to edit.';
    	}
    	
    	$this->view->status_types = $this->user->getStatusTypes();
    	$this->view->password_default = $password_default;
    	$this->view->user   = $user;
    	$this->view->error  = $error;
		$this->view->status = $status;
    }
    
    
    /**
     * Register user with new field.
     * This action will replace add once completed
     * @access public
     */
    public function registerAction() {
    	// Defaults
    	$error  = null;
    	$status = null;
    	
    	$entity = new Application_Model_Userentity($this->user);
    	
    	$users = $entity->getAll();
    	
    	if ($this->request->isPost()) {
	    	// Check our post array
			$post = $this->request->getPost();
			
			if (!empty($post)) {
				if ($entity->exists('user','username',$post['username'])) {
					$status = false;
					$error  = 'Username already taken.';
				} else {
					// Special handling for passwords
					if (array_key_exists('password', $post)) {
		                // Use a special method for updating passwords
		                $post['password'] = $entity->encryptPassword($post['password']);
		            }
		            
		    		// Add the entity with all of the passed info
		    		$entity->addWithMeta($post);
	    			
		    		$status = $entity->isValid();
		    		$error  = $entity->getError();
		    	}
			} else {
				$error = 'No data was presented to create the user with.';
			}
		}
		
		$this->view->status_types = $this->user->getStatusTypes();
		
		$this->view->error  = $error;
		$this->view->status = $status;
    }    
    
}

