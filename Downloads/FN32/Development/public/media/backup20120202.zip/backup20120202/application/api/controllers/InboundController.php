<?php
class Api_InboundController extends ApiControllerAbstract {
	/**
	 * Object initializer
	 * 
	 * @see Zend_Controller_Action::init()
	 */
	public function init() {
		// Tells the framework to not render view templates or layouts
		$this->_helper->viewRenderer->setNoRender(true);
		$this->_helper->layout()->disableLayout();
	}
	
	public function indexAction() {
		$this->_notImplemented();
	}
	
	public function getAction() {
		$this->_notImplemented();
	}
	
	public function postAction() {
		// Get the inbound body
		$inboundbody = $this->_request->getPost('message');
		$inboundbody = trim(strtolower($inboundbody));
		
		
		/*# Extract values and create timestamped output line
$output = date("r", time()) . " -- ";
$output .= "Message: " . $this->_request->getPost('message') . "; ";
//$output .= "Carrier: " . $this->_request->getPost('carrier') . "; ";
//$output .= "Channel: " . $this->_request->getPost('channel') . "; ";
$output .= "Device address: " . $this->_request->getPost('device_address') . "\n";
# Write output to file
$log = realpath(dirname(__FILE__)) . '/DirectTEXTReceived.txt';
$fh = fopen($log, 'a') or die("can't open file");
fwrite($fh, $output);
fclose($fh);*/

	if ($inboundbody == 'roberttest') {
			$inboundbody = 'stop';
		}
		
		// Get the senders phone number
		$sender = $this->_request->getPost('device_address');
		
		// Grab the message, write the inbound
		//$status = new Application_Model_Smsinbound;
		$in = new Application_Model_Smsinbound();
		
		
		//$in->subscriberid = $this->getSubscriberId();
		$in->device_address  = $sender;
		$in->inbound_address = $this->_request->getPost('inbound_address');
		$in->router          = $this->_request->getPost('router');
		$in->carrier         = $this->_request->getPost('carrier');
		$in->channel         = $this->_request->getPost('channel');
		$in->message         = $inboundbody;
		$in->message_id      = $this->_request->getPost('message_id');
		$in->message_orig    = $this->_request->getPost('message_orig');
		$in->router          = $this->_request->getPost('router');
		$in->status          = $this->_request->getPost('status');
		$in->status_code     = $this->_request->getPost('status_code');
		
		//Get the id of the last message out 
		$in->replyto_message_id = $in->getReplyToMessageId();
		
		// See if this is a keyword and get its ID if it is.
		$in->keywordid = $in->getKeywordId($inboundbody);
		
		// Save the folder id if there is one
		$in->folderid = $in->getFolderId();
		
		// Now save the constructed inbound
		// Roles reversed to allow for depth tracking
		$in->handleKeywordActions($in->getReplytoMessage());
		$in->save();
		
		$log = realpath(dirname(__FILE__)) . '/logmo.txt';
		ob_start();
		echo "POST:\n";
		var_dump($_POST);
		echo "\nGET\n";
		var_dump($_GET);
		$write = ob_get_contents();
		ob_end_clean();
		$fh = fopen($log, 'a');
		fwrite($fh, "\n$write\n");
		fclose($fh);
		$this->setOutputParam('message', 'Message received');
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
}
