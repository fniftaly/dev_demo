<?php
class Application_Model_Smsinbound extends Application_Model_Abstract {
	/**
	 * A message ID, for getting an existing message
	 * 
	 * @access public
	 * @var int
	 */
	public $id = 0;
	
	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $subscriberid = 0;
	
	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $createtime;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $carrier;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $channel;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $device_address;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $inbound_address;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $message;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $message_id;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $message_orig;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $router;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $status;
	
	/**
	 * ID of the originating keyword for this message, if there is one.
	 * 
	 * @access public
	 * @var int
	 */
	public $keywordid;

	/**
	 * PROPDESCRIPTION
	 * 
	 * @access public
	 * @var PROPTYPE
	 */
	public $status_code;
	
	/**
	 * Message depth, for conversation tracking
	 * 
	 * @access public
	 * @var int
	 */
	public $depth = 0;
	
	public function __construct($id = 0) {
		$this->_getDbh();
        $this->_load($id);
	}
	
	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getSubscriberId() {
		return $this->subscriberid;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $subscriberId ARGDESCRIPTION
	 */
	public function setSubscriberId($subscriberId) {
		$this->subscriberid = $subscriberId;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getCreatetime() {
		return $this->createtime;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $createtime ARGDESCRIPTION
	 */
	public function setCreatetime($createtime) {
		$this->createtime = $createtime;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getCarrier() {
		return $this->carrier;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $carrier ARGDESCRIPTION
	 */
	public function setCarrier($carrier) {
		$this->carrier = $carrier;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getChannel() {
		return $this->channel;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $channel ARGDESCRIPTION
	 */
	public function setChannel($channel) {
		$this->channel = $channel;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getDeviceAddress() {
		return $this->device_address;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $deviceAddress ARGDESCRIPTION
	 */
	public function setDeviceAddress($deviceAddress) {
		$this->device_address = $deviceAddress;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getInboundAddress() {
		return $this->inbound_address;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $inboundAddress ARGDESCRIPTION
	 */
	public function setInboundAddress($inboundAddress) {
		$this->inbound_address = $inboundAddress;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getMessage() {
		return $this->message;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $message ARGDESCRIPTION
	 */
	public function setMessage($message) {
		$this->message = $message;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getMessageId() {
		return $this->message_id;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $messageId ARGDESCRIPTION
	 */
	public function setMessageId($messageId) {
		$this->message_id = $messageId;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getMessageOrig() {
		return $this->message_orig;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $messageRaw ARGDESCRIPTION
	 */
	public function setMessageOrig($messageOrig) {
		$this->message_orig = $messageOrig;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getRouter() {
		return $this->router;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $router ARGDESCRIPTION
	 */
	public function setRouter($router) {
		$this->router = $router;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getStatus() {
		return $this->status;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $status ARGDESCRIPTION
	 */
	public function setStatus($status) {
		$this->status = $status;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getStatusCode() {
		return $this->status_code;
	}

	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $statusCode ARGDESCRIPTION
	 */
	public function setStatusCode($statusCode) {
		$this->status_code = $statusCode;
	}
	
	public function getfolderid1(){
	//$sql = "select folderid from subscribers where phonenumber='$this->device_address' order by id desc";
	$sql = "CALL message_get_lastoutboundid('$this->device_address')";
		$rs = $this->query($sql);
		if ($rs && $rs->num_rows) {
				$row = $rs->fetchObject();
				if ($row->messageid) {
					return $row->messageid;
				}
			}
	
	}
	
	
	public function optOut1() {
	
	//echo "I am here in keyword abstract";
		// Check if this is a single folder subscriber first...
		$subscriber = new Application_Model_Subscriber();
		$folders = $subscriber->getContainingFolders($this->device_address, false);
		//echo $folders[0]->folderid;
		//echo "count folder".count($folders);
		if ($folders && is_array($folders) && count($folders) == 1) {
			// Unsubsribe from this folder
			$this->optOutSubscriber1($folders[0]->folderid, $this->device_address);
		} else {
			$outbound = $this->getReplytoMessage();
			//print_r($outbound);
			//echo "folderid".$outbound->folderid;
			//die;
			if ($outbound && $outbound->folderid) {
				//$user = Zend_Registry::isRegistered('user') ? Zend_Registry::get('user') : new Application_Model_User($outbound->createuser);
				//$folder = new Application_Model_Folder($user, $outbound->folderid);
				$this->optOutSubscriber1($outbound->folderid, $this->device_address);
			}
			//$this->_keyword->deleteSubscriber($this->_sender);
		}
	} 
	
	/**
     * Opts a subscriber out of a folder
     * 
     * @param string $phone
     * @return boolean
     */
    public function optOutSubscriber1($folder, $phone) {
		 $sql = "CALL folder_delete_subscriber($folder, $phone)";
		$this->_writeLog("Opt out: $sql");
		$rs = $this->query($sql);
		echo "finally here first";
		///////////////////////////
		
		
		$apiUrl = 'https://secure-mrr.air2web.com/a2w_preRouter/httpApiRouter';
$shortCode = '87365';
$sendTo = array($phone);
$sendMessage = urlencode("STOP:You have been unsubscribed");
$username = 'textmu';
$password = 'textmu1';

		$reportingkey1 = time();
		$reportingkey2 = md5(uniqid() . serialize($phone));
	echo $uri = $apiUrl . '?reply_to=' . $shortCode . '&recipient=' . implode('&recipient=', $sendTo) . '&body=' . $sendMessage . '&reporting_key1=' . $reportingkey1 . '&reporting_key2=' . $reportingkey2;
			
			
		
		$ch = curl_init($uri);
			
			// Now set some params, start with username and password
			curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);
			
			// Turn off header output in the response
			curl_setopt($ch, CURLOPT_HEADER, false);
			
			// Disable SSL peer verification
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			
			// Capture the output instead of echoing it
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			
			// Execute our request
			$rs = curl_exec($ch);
			
			// Close the cURL handle
			curl_close($ch);
			
			// Now lets inspect it and see if we have what we need
			$response = simplexml_load_string($rs);
			
			// Type cast the response code and description for use
			$code = intval($response->code);
			echo $description = "$response->description";
		
		
		
		/////////////////////////////////////
		return $rs->success > 0;
    } 
    
	
	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @return RETURNTYPE RETURNDESCRIPTION
	 */
	public function getReplytoMessageId() {
		// If there is an inbound ID, we're reading one we've already written
		if ($this->id) {
			return $this->replyto_message_id;
		}
		
		// This is a new message coming in, so look backward to get the last outbound to it
		// We can only do this though if we've captured the from phone number
		if ($this->device_address) {
			$sql = "CALL message_get_lastoutboundid('$this->device_address')";
			$rs = $this->query($sql);
			
			if ($rs && $rs->num_rows) {
				$row = $rs->fetchObject();
				if ($row->messageid) {
					return $row->messageid;
				}
			}
		}
		
		return '';
	}
	
	/**
	 * Gets the last outbound for this inbound
	 * 
	 * @access public
	 * @return stdClass A row from the messages outbound table and recipients table
	 */
	public function getReplytoMessage() {
		// Get the last message out that we know from the phone number
		if ($this->device_address) {
			$sql = "CALL message_get_lastoutboundid('$this->device_address')";
			$rs = $this->query($sql);
			
			if ($rs && $rs->num_rows) {
			//echo "yes row returned";
				return $rs->fetchObject();
			}
		}
		
		return null;
	}
	
	/**
	 * Finds out of the passed message is a keyword. If so, 
	 * sets and returns the keyword id.
	 * 
	 * @access public
	 * @param string $message
	 * @return bool|int
	 */
	public function getKeywordId($message) {
		$keyword = new Application_Model_Keyword($this->message, true);
		
		// If it was a real keyword it would have loaded a folder
		if ($keyword->folderid) {
			$this->_writeLog("Inbound getKeyword ID: $keyword->id");
			return $keyword->id;
		}
		
		// if this was not a keyword, see if there is a replyto message
		if ($this->replyto_message_id) {
			// If we have a replyto message, see if it has a keyword id
			$replytomessage = $this->getReplytoMessage();
			
			if ($replytomessage->keywordid) {
				return $replytomessage->keywordid;
			}
		}
		
		return false;
	}
	
	/**
	 * Looks for a folder id in the replytomessage to see what folder
	 * the subscriber belongs to for this conversation. This is what
	 * will be used to opt them out if this is an opt out message.
	 * 
	 * @access public
	 * @return bool|int
	 */
	public function getFolderId() {
		// if there was a replyto message see if it has a folder id
		if ($this->replyto_message_id) {
			// If we have a replyto message, see if it has a folder id
			$replytomessage = $this->getReplytoMessage();
			
			if ($replytomessage->folderid) {
				return $replytomessage->folderid;
			}
		}
		
		return false;
	}
	
	/**
	 * METHODDESCRIPTION
	 * 
	 * @access public
	 * @param ARGTYPE $replytoMessageId ARGDESCRIPTION
	 */
	public function setRelpytoMessageId($replytoMessageId) {
		$this->replyto_message_id = $replytoMessageId;
	}
	
	public function save() {
		$message      = $this->_dbh->real_escape_string($this->message);
        $message_orig = $this->_dbh->real_escape_string($this->message_orig);
        
        $sql = "CALL message_log_inbound(
			'$this->subscriberid', '$this->carrier', '$this->channel', '$this->device_address',
			'$this->inbound_address', '$message', '$this->message_id', '$message_orig',
			'$this->router', '$this->status', '$this->status_code', '$this->replyto_message_id', 
			'$this->keywordid', '$this->folderid', $this->depth
		)";
		
		$rs = $this->query($sql);
		
		if ($this->hasError()) {
	        error_log($this->getError());
	        $this->error = 'Unable to log inbound message';
	        return false;
	    }
	    
	    return true;
	}
	
	public function handleKeywordActions($replytomessage = null) {
		// LOG IT for testing
		$this->_writeLog("ReplyToMessage is " . print_r($replytomessage, 1));
		
		// See if this matches a keyword and handle special cases
		$keyword = new Application_Model_Keyword($this->message, true);
		$this->_writeLog("Keyword folderid: $keyword->folderid" );
		
		// just hacking this for now
		if (!in_array(strtolower($this->message), array('stop','end','quit','info','help'))) {
		
			// if it didn't load a folderid, it is probably not a valid keyword
			// Now check if there is a replytomessageid and this is a response to
			// a previous outbound
			if (empty($keyword->folderid)) {
				if ($replytomessage) {
					
					$this->_writeLog("Originating Keyword ID: $replytomessage->keywordid");
					$keyword = new Application_Model_Keyword($replytomessage->keywordid);
				}
			}
			// If there is a replytomessage, get the create user. This will be for all campaign replies, as well
                        // as multi level conversations. If there is no replytomessage we should ALWAYS have a keyword, so 
                        // get the user that currently owns that keyword and send the reply back as them.
			$creatorid = !empty($replytomessage->createuser) ? $replytomessage->createuser : $keyword->createuser;
			
		} else {
			$creatorid = 0;
		}
		
		// Prepare the reply messages if there is one
		$keyword->response  = $keyword->replyheader ? "{$keyword->replyheader}:" : '';
		$keyword->response .= "{$keyword->replybody}\n{$keyword->replyfooter}";
		
		// Handle special actions
		$keyword->handleSpecialActions($this);
		
		// LOG IT for testing
		$this->_writeLog("Keyword ID is $keyword->id");
		
		// If we have an id then this is a keyword
		if ($keyword->id) {
			// LOG IT for testing
			$this->_writeLog("Opted Out Flag is $keyword->optedOut");


			// LOG IT for testing
			$this->_writeLog("Message Creator is $creatorid");
			
			$message = new Application_Model_Message(new Application_Model_User((int) $creatorid));
			
			// Set the message keyword and folder id's. These will be used for tracking a conversation as well as handling optouts
			$message->keywordid = $keyword->id;
			$message->folderid  = $keyword->folderid;
			
			// This would only be set from a SpecialAction model
			if (!$this->optedOut) {
				$this->_writeLog("non-optout");
				// Subscribe this sender, but only if they are not already a subscriber
				if (!$keyword->hasSubscriberPhone($this->device_address)) {
					// Depth for this message is 1 since we are an optin
					$this->depth = 1;
					
					// Sign them up for this keyword
					$keyword->addSubscriber($this->device_address);
					$this->_writeLog("add subscriber: $this->device_address, response: $keyword->response");
					// If there is an autoreply, send it now
					if ($keyword->response) {
						$message->sendNow($keyword->response, array($this->device_address));
					}
				} else {
					if (!$keyword->usecustomresponse) {
						// If there is an alternate autoresponder
                        if ($keyword->usealt) {
                            $keyword->response  = $keyword->replyheader ? "{$keyword->replyheader}:" : '';
                            $keyword->response .= "{$keyword->replybodyalt}\n{$keyword->replyfooter}";
                        } else {
                            // Otherwise provide a default one.
                            $keyword->response = 'You are already opted in. Thanks for your message.';
                            // TODO: ACTUALLY WE WANT THE 1ST ONE TO KEEP GOING OUT, BUT ALTERNATE RESPONSES
                            // NEED TO BE SET UP FOR ALL EXISTING KEYWORDS 1ST SINCE IT IS A NEW FEATURE
                        }
					}
					$this->_writeLog("already opted in: $keyword->response");
					//$message->sendNow($keyword->response, array($this->device_address));
				}
			} else {
				/* Taking out for now so stop messages can send their default responses
				Actually, I think this might be unnecessary, because if a custom message is set
				it will override the reponse and be used below...
				if (!$keyword->usecustomresponse) {
					$keyword->response = 'Your message has been received.';
				}*/
				$this->_writeLog("OptOut $keyword->response");
				$message->sendNow($keyword->response, array($this->device_address));
			}
		}
	}
	
	/**
	 * Loads up this model with data from the database
	 *
	 * @access protected
	 * @param int $id The id to load
	 * @return boolean
	 */
	protected function _load($id = 0) {
		if ($id) {
			$sql = "CALL message_get_inbound($id)";
			
			$rs = $this->query($sql);
			
			if ($this->hasError()) {
				$this->setError('Unable to load inbound message', $this->getError());
				return false;
			}
			
			foreach ($rs->fields as $key => $value) {
				if (property_exists($this, $key)) {
					$this->{$key} = $value;
				}
			}
			
			return true;
		}
		
		return false;
	}
}
