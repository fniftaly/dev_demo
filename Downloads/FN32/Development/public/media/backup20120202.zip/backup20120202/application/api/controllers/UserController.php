<?php
class Api_UserController extends ApiControllerAbstract {
	/**
	 * Username that we are working with
	 *
	 * @access protected
	 * @var string
	 */
	protected $_username;
	
	/**
	 * Grab the username from the uri if it is available
	 *
	 * @access public
	 */
	public function preDispatch() {
		$this->_username = $this->_request->getParam('id');
	}
	
	public function indexAction() {
		$this->_notImplemented();
	}
	
	/**
	 * Get a user account details
	 *
	 * @access public
	 */
	public function getAction() {
		$user = new Application_Model_User($this->_username);
		$this->setOutputParam('body', $user);
		$this->setOutputParam('status', $user->isValid());
		$this->setOutputParam('error', $user->error);
	}
	
	/**
	 * Create a new user
	 *
	 * @access public
	 */
	public function postAction() {
		// Check our post array
		$post = $this->_request->getPost();
		if (!empty($post)) {
			$user = new Application_Model_User();
			$user->setUsername($this->_request->getPost('username'));
			$user->setFirstname($this->_request->getPost('firstname'));
			$user->setLastname($this->_request->getPost('lastname'));
			$user->setEmail($this->_request->getPost('email'));
			$user->setPassword($this->_request->getPost('password'));
			$user->setSalt($this->_request->getPost('salt'));
			$user->setApikey($this->_request->getPost('apikey'));
			$user->setApisecret($this->_request->getPost('apisecret'));
			
			$this->setOutputParam('status', $user->create());
			$this->setOutputParam('error', $user->error);
		} else {
			$this->_setOutputParam('error', 'No data was presented to create the user with');
		}
	}
	
	/**
	 * Update a user
	 *
	 * @access public
	 */
	public function putAction() {
		$user = new Application_Model_User($this->_username);
		
		$data = $this->getBodyParams();
		
		$this->setOutputParam('status', $user->update($data));
		$this->setOutputParam('error', $user->error);
		$this->setOutputParam('message', empty($data) ? 'No data was passed to update the user with.' : null);
	}
	
	/**
	 * Delete a user
	 *
	 * @access public
	 */
	public function deleteAction() {
		$user = new Application_Model_User($this->_username);
		$this->setOutputParam('status', $user->delete());
		$this->setOutputParam('error', $user->error);
	}
}
