<?php
abstract class Application_Model_RedeemAbstract extends Application_Model_Abstract {
	public function redeem() {
		
	}
}