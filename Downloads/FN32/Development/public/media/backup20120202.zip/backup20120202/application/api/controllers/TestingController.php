<?php
class Api_TestingController extends ApiControllerAbstract {
    /*
    public function init() {
        $this->_helper->viewRenderer->setNoRender(true);
    }*/
    
    public function indexAction() {
    	$dr = new Application_Model_Deliveryreport();
    	$dr->writeLog();
    }
    
    public function getAction() {
		$this->_notImplemented();
	}
	
	public function postAction() {
		$this->_notImplemented();
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
}

