<?php
/** 
 * @author Robert Gonzalez
 * 
 * Simple abstract controller for all API objects to extend
 */
abstract class ApiControllerAbstract extends Zend_Rest_Controller {
	/**
	 * The requested response format
	 * 
	 * @access protected
	 * @var string
	 */
	protected $_format = 'json';
	
	/**
	 * The name of the requested module
	 * 
	 * @var string
	 */
	protected $_moduleName;
	
	/**
	 * Allowed response formats
	 * 
	 * @access protected
	 * @var array
	 */
	protected $_allowedFormats = array('json', 'xml');
	
	/**
	 * @var array Parameters detected in raw content body
	 */
	protected $_bodyParams = array();
	
	/**
	 * Collection of data that is sent as part of every response
	 *
	 * @access protected
	 * @var array
	 */
	protected $_outputParams = array(
		'status'  => false,
		'message' => null,
		'error'   => null,
		'body'    => null,
	);
	
	protected $stop = false;
	
	protected $_requestId = 0;
	
	/**
	 * List of controller names that DO NOT need authentication
	 * 
	 * @access protected
	 * @var Array
	 */
	protected $_noAuthRequired = array(
		'Inboundmo',
		'Inbounddr'
	);
	
	/**
	 * Object initializer
	 * 
	 * @see Zend_Controller_Action::init()
	 */
	public function init() {
		// Tells the framework to not render view templates or layouts
		$this->_helper->viewRenderer->setNoRender(true);
		$this->_helper->layout()->disableLayout();
		
		// Set our request id
		$this->_requestId = $this->_request->getParam('id');
		$this->_outputParams['requestid'] = $this->_requestId;
		
		// Set the module name
		$this->_setModuleName();
		
		// Handle passed params based on format sent
		$contentType = $this->_request->getHeader('Content-Type');
		$rawBody     = $this->_request->getRawBody();
		
		// Set our body params
		switch (true) {
			case (strstr($contentType, 'application/json')):
				$this->setBodyParams(Zend_Json::decode($rawBody));
				$this->_setFormatFromRequest('json');
				break;
			case (strstr($contentType, 'application/xml')):
				$config = new Zend_Config_Xml($rawBody);
				$this->setBodyParams($config->toArray());
				$this->_setFormatFromRequest('xml');
				break;
			default:
				if ($this->_request->isPut()) {
					//parse_str($rawBody, $params);
					//$this->setBodyParams($params);
					$this->setBodyParams($this->_parseRawBody($rawBody));
				}
				break;
		}
		
		// Sets the expected response format
		$this->setFormat();
		
		// Validate this request by API Key if it is required
		if ($this->_requiresAuth()) {
			
			/** 
			 * Now see how we are authenticating
			 * There are 2 ways:
			 *   1) API key passed via Header
			 *   2) Username/Password passed via url 
			 */
			 
			$auth = new Application_Model_Auth();
			
			// Check for a username 1st
			$username = $this->_requestParam('username');
			$password = $this->_requestParam('password');
			
			// We'll check for username/password first
			if ($username && $password) {
				$authorized = $auth->authenticate($username, $password);
			} else {
				$apikey = $this->_request->getHeader('X-Api-Key');
				$authorized = $auth->validate($apikey);
			}
			
			// Did the authorization fail?
			if ($authorized == false) {
				$this->setError($auth->getError(), 401, true);
			}
			
			// If we made it here, we have a valid api user.
			// Get the userid and build a user model so it 
			// we can identify this user in other models.
			$this->apiuser = $auth->getAuthorizedUserId();
			
			// Load the api users User Profile
			$this->apiuser = new Application_Model_User($this->apiuser);
			
			// If the user model did not create for some reason, stop and return the error.
			if ($this->apiuser->hasError()) {
	            $this->setError($this->apiuser->getError(), 500, true);
			}
			
			// now register the apiuser model to the registry
			Zend_Registry::set('user', $this->apiuser);
		}
	}
	
	/**
	 * Set an output error text, set the status to false, and
	 * set the http response code.
	 * 
	 * @access protected
	 * @param string $msg Error message to be displayed
	 * @param int $code HTTP Response code to use for response
	 * @param bool $redirect Should we redirect to the error page? This should only be set from the AbstractController init() function
	 */
	protected function setError($msg, $code = 200, $redirect = false) {
		$this->setOutputParam('status', false);
        $this->setOutputParam('error', $msg);
        $this->_response->setHttpResponseCode($code);
		if ($redirect) {
			$this->_forward('error');
		}
	}
	
	/**
	 * Sets the response format from either the request or by passing it
	 * 
	 * @access public 
	 * @param string $format
	 */
	public function setFormat($format = null) {
		// Handle format setting, from an argument OR the raw request OR the general request
		if ($format || ($format = $this->getBodyParam('format')) !== null || ($format = $this->_request->getParam('format')) !== null) {
			if (in_array($format, $this->_allowedFormats)) {
				$this->_format = $format;
			}
		}
	}
	
	/**
	 * Default Actions for each request type
	 */
	public function indexAction() {
		$this->_notImplemented();
	}
	public function getAction() {
		$this->_notImplemented();
	}
	public function postAction() {
		$this->_notImplemented();
	}
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
	public function errorAction() {
		/*$status  = $this->_getParam('status');
		$message = $this->_getParam('message');
		$error   = $this->_getParam('error');
		$body    = $this->_getParam('body');
		
		$this->setOutputParam('status', $status);
		$this->setOutputParam('message', $message);
		$this->setOutputParam('error', $error);
		$this->setOutputParam('body', $body);
		*/
	}
	
	/**
	 * Set body params
	 *
	 * @param array $params
	 */
	public function setBodyParams(array $params) {
		$this->_bodyParams = $params;
	}

	/**
	 * Retrieve body parameters
	 * 
	 * @return array
	 */
	public function getBodyParams() {
		return $this->_bodyParams;
	}

	/**
	 * Get body parameter
	 *
	 * @param string $name
	 * @param mixed $default A default value to return in the event the param is
	 *                       not found
	 * @return mixed
	 */
	public function getBodyParam($name, $default = null) {
		return $this->hasBodyParam($name) ? $this->_bodyParams[$name] : $default;
	}

	/**
	 * Is the given body parameter set?
	 *
	 * @param  string $name
	 * @return bool
	 */
	public function hasBodyParam($name) {
		return array_key_exists($name, $this->_bodyParams);
	}

	/**
	 * Do we have any body parameters?
	 *
	 * @return bool
	 */
	public function hasBodyParams() {
		return !empty($this->_bodyParams);
	}
	
	/**
	 * Universal accessor to the main output params
	 *
	 * @access public
	 * @param string $param The param to set
	 * @param mixed $value The value to set the param to
	 * @return boolean
	 */
	public function setOutputParam($param, $value) {
		if ($this->hasOutputParam($param)) {
			$this->_outputParams[$param] = $value;
			return true;
		}
		
		return false;
	}
	
	/**
	 * Gets an output param or alternate, default value
	 *
	 * @access public
	 * @param string $param The name of the output param
	 * @param mixed $default The alternate value to return
	 * @return mixed
	 */
	public function getOutputParam($param, $default = null) {
		return $this->hasOutputParam($param) ? $this->_outputParams[$param] : $default;
	}
	
	/**
	 * Checks to see if there is an output param of the given name
	 *
	 * @access public
	 * @param string $param The output param to check
	 * @return boolean
	 */
	public function hasOutputParam($param) {
		return array_key_exists($param, $this->_outputParams);
	}
	
	/**
	 * Checks to see if an output param has a value
	 *
	 * @access public
	 * @param string $param The output param to check
	 * @return boolean
	 */
	public function hasOutputParamValue($param) {
		return !empty($this->_outputParams[$param]);
	}
	
	/**
	 * Post Dispatch method that handles output for our controllers
	 *
	 * @access public
	 */
	public function postDispatch() {
		$this->_sendOutput($this->_outputParams);
	}
	
	/**
	 * Sets a format from the request
	 *
	 * @access protected
	 * @param string $form
	 */
	protected function _setFormatFromRequest($format) {
		if ($this->getBodyParam('format') === null && $format = $this->_request->getParam('format') === null) {
			$this->setFormat($format);
		}
	}
	
	/**
	 * Sends output to the client
	 * 
	 * @access protected
	 * @param mixed $msg
	 */
	protected function _sendOutput($msg) {
		// Send our API version - This needs to be dynamic
		header('X-API-Version: 0.1a');
		
		// Send our throttle limit
		header('X-API-Throttle-Limit: 100');
		
		// Send our throttle count
		header('X-API-Throttle-Count: 1');
		
		// When preparing our output, send the corrent content type header
		if ($this->_format == 'json') {
			header('Content-Type: application/json');
			$msg = json_encode($msg);
		} else {
			header('Content-Type: text/xml');
			if (is_string($msg)) {
				$msg = array('Response' => $msg);
			}
			
			$msg = $this->_getXML($msg);
		}
		
		$this->getResponse()->appendBody($msg);
	}
	
	/**
	 * Sets the currently requested module name
	 */
	protected function _setModuleName() {
		$this->_moduleName = str_replace(array('Controller', 'Api_'), '', get_class($this));
	}
	
	/**
	 * Simple method to output that a given request method is not yet implemented
	 * for a given module
	 */
	protected function _notImplemented() {
		$this->setOutputParam('error', "$_SERVER[REQUEST_METHOD] requests for the $this->_moduleName segment of our API are currently unavailable.");
	}
	
	/**
	 * Utility method that gets either a request param (1st priority) or a body
	 * param (2nd priority)
	 *
	 * @access protected
	 * @param string $label The param label to get the value for
	 * @param mixed $value The default value to return if the param isn't found
	 * @return mixed The value for this param
	 */
	protected function _requestParam($label, $value = null) {
		if (($param = $this->_request->getParam($label, '__EMPTYSTRING__')) === '__EMPTYSTRING__') {
			if (($param = $this->getBodyParam($label, '__EMPTYBSTRING__')) === '__EMPTYBSTRING__') {
				return $value;
			}
		}
		
		return $param;
	}
	
	/**
	 * Method to turn an Array into XML
	 * 
	 * I totally ganked this from the manual
	 * 
	 * @param array $array
	 * @param string $rootNode
	 * @return string An XML string of the data passed
	 */
	protected function _getXML(Array $array, $rootNode = 'Response') {
		$xml = new SimpleXMLElement("<?xml version=\"1.0\"?><{$rootNode}></{$rootNode}>");
		$f = create_function('$f, $c, $a', '
			foreach ($a as $k => $v) {
				if (is_array($v)) {
					$ch = $c->addChild($k);
					$f($f, $ch, $v);
				} else {
					$c->addChild($k, $v);
				}
			}');
		$f($f, $xml, $array);
		return $xml->asXML();
	}
	
	/**
	 * Parses a raw body request string
	 *
	 * This works similar to parse_str except it will correctly handle multiple
	 * params of the same name without overriding previous values. Will also
	 * scalarize single value elements to keep consistent with XML and JSON
	 * handling
	 *
	 * @access protected
	 * @param string A query string
	 * @return array An array of params based on the request
	 */
	protected function _parseRawBody($str) {
		// Set up the return
		$return = array();
		
		// Explode on the ampersand
		$parts = explode('&', $str);
		
		// Loop each part and build from it
		foreach ($parts as $part) {
			$inner = explode('=', $part);
			$return[$inner[0]][] = $inner[1];
		}
		
		// Now scalarize single element arrays for uniformity
		foreach ($return as $key => $val) {
			$return[$key] = count($val) == 1 ? $val[0] : $val;
		}
		
		return $return;
	}
	
	/**
	 * Checks to see if this request requires authentication
	 * 
	 * Some requests, like inbound MO, do not require authentication because 
	 * they are simply post requests coming from an HTTP request
	 * 
	 * @access protected
	 * @return boolean
	 */
	protected function _requiresAuth() {
		preg_match('/Api_(.*)Controller/i', get_class($this), $matches);
		if (!empty($matches[1][0])) {
			return !in_array($matches[1][0], $this->_noAuthRequired);
		}
		
		return true;
	}
}
