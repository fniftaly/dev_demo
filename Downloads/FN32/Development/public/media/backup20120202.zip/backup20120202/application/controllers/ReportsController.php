<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class ReportsController extends AuthorizedController {
    
    public function messageAction() {
        /*$userid = $this->user->getId();
        $messageObj = new Application_Model_Report();
        $numbermessage_currmonth = $messageObj->getMessageCountList($userid);
        $this->view->numbermessage_currmonth  = $numbermessage_currmonth;*/

         
         /*if ($this->request->isPost())
           {*/
             $rmonth = "";
             $ryear = "";
             $seereportby = $this->request->getParam('reportby');
             if($this->request->getParam('searchvaluehide')!='')
                    $searchvalue = $this->request->getParam('searchvaluehide');
             else
                    $searchvalue = $this->request->getParam('searchvalue');
             if($seereportby=="month")
             {
                 $rmonth = $this->request->getParam('monthMessageReport');
                 $ryear = $this->request->getParam('yearMessageReport');
                 if($rmonth==0 OR $ryear==0)
                  {
                     $monthstartdate = 0;
                     $monthenddate = 0;
                  }else{
                         $monthstartdate = $ryear."-".$rmonth."-1 00:00:00"; 
                         $monthenddate = $ryear."-".$rmonth."-30 00:00:00";                 
                 }                      
             }elseif($seereportby=="date")
             {
                $monthstartdate = date("Y-m-d",strtotime($this->request->getParam('starttime')));
                $monthenddate = date("Y-m-d",strtotime($this->request->getParam('endtime')));         
             }elseif($seereportby=="")
             {
                 $monthstartdate = date('Y')."-".date('m')."-1 00:00:00";
                 $monthenddate = date('Y')."-".date('m')."-30 00:00:00";                  
             }
           /*}else{
                $searchvalue = $this->request->getParam('searchvalue');
                if($rmonth=='' OR $ryear==''){
                         $monthstartdate = date('Y')."-".date('m')."-1 00:00:00";
                         $monthenddate = date('Y')."-".date('m')."-30 00:00:00"; 
                }               
           }*/
        
        $reportObj =  new Application_Model_Report();
        
        $pagenum = $this->request->getParam('page');
        if($pagenum=='' OR $pagenum==0)
          $pagenum = 1;
                

        $arraystart = ($pagenum*5) - 5 ;
        $arrayend = ($pagenum*5);        
        
        if($this->request->getParam('reportuserid')!='')
              $userid = $this->request->getParam('reportuserid');
           else     
              $userid = $this->user->getId();          
        
        if($reportObj->checkAdminUser($userid))  
        {
            $this->view->userTypeshowing = 'users'; 
            $subUsersArray = $reportObj->findChildEntityList($userid,5,$searchvalue);  //echo "<pre>"; print_r($subUsersArray); exit;
            $totalSubUsers = count($subUsersArray);
            
            
            foreach ($subUsersArray as $key => $row) {
                $username[$key]  = $row['username'];
            } 
            $orderby = $this->request->getParam('orderby');
            if($orderby == 'ASC')
                array_multisort($username, SORT_ASC, $subUsersArray);
            elseif($orderby == 'DESC')
                array_multisort($username, SORT_DESC, $subUsersArray);
            //echo "<pre>"; print_r($subUsersArray); exit;    
            $this->view->sortOrderBy = $orderby;
            

            //$this->view->userlist = $subUsersArray;
            $allDetailsArray = array();

             /*foreach($subUsersArray as $subUser)
            {
                $allDetailsArray[$subUser['childuserid']]['username'] = $subUser['username'];
               $allDetailsArray[$subUser['childuserid']]['totalKeywords'] = $reportObj->reportCountTotalKeywordByUserId($subUser['childuserid'],$monthstartdate,$monthenddate);
                $allDetailsArray[$subUser['childuserid']]['totalOptins'] = $reportObj->reportCountTotalOptinsByUserId($subUser['childuserid'],$monthstartdate,$monthenddate); 
                $allDetailsArray[$subUser['childuserid']]['totalOptouts'] = $reportObj->reportCountTotalOptoutsByUserId($subUser['childuserid'],$monthstartdate,$monthenddate); 
                $allDetailsArray[$subUser['childuserid']]['totalCampaigns'] = $reportObj->reportCountTotalCampaignsByUserId($subUser['childuserid'],$monthstartdate,$monthenddate); 
                $allDetailsArray[$subUser['childuserid']]['totalCampaignMessages'] = $reportObj->reportCountTotalCampaignMessagesByUserId($subUser['childuserid'],$monthstartdate,$monthenddate);
                $allDetailsArray[$subUser['childuserid']]['totaloutboundmessage'] = $reportObj->reportCountTotalMessagesByUserId($subUser['childuserid'],$monthstartdate,$monthenddate);
            }*/

            for($i = $arraystart; $i< $arrayend; $i++)
            { 
                if(!empty($subUsersArray[$i]))
                {
                    $allDetailsArray[$subUsersArray[$i]['childuserid']]['username'] = $subUsersArray[$i]['username'];
                    $allDetailsArray[$subUsersArray[$i]['childuserid']]['totalKeywords'] = $reportObj->reportCountTotalKeywordByUserId($subUsersArray[$i]['childuserid'],$monthstartdate,$monthenddate);
                    $allDetailsArray[$subUsersArray[$i]['childuserid']]['totalSubscribers'] = $reportObj->reportCountTotalSubscribersByUserId($subUsersArray[$i]['childuserid'],$monthstartdate,$monthenddate);
                    $allDetailsArray[$subUsersArray[$i]['childuserid']]['totalOptins'] = $reportObj->reportCountTotalOptinsByUserId($subUsersArray[$i]['childuserid'],$monthstartdate,$monthenddate);
                    $allDetailsArray[$subUsersArray[$i]['childuserid']]['totalOptouts'] = $reportObj->reportCountTotalOptoutsByUserId($subUsersArray[$i]['childuserid'],$monthstartdate,$monthenddate); 
                    $allDetailsArray[$subUsersArray[$i]['childuserid']]['totalCampaigns'] = $reportObj->reportCountTotalCampaignsByUserId($subUsersArray[$i]['childuserid'],$monthstartdate,$monthenddate);
                    $allDetailsArray[$subUsersArray[$i]['childuserid']]['totalCampaignMessages'] = $reportObj->reportCountTotalCampaignMessagesByUserId($subUsersArray[$i]['childuserid'],$monthstartdate,$monthenddate);
                    $allDetailsArray[$subUsersArray[$i]['childuserid']]['totaloutboundmessage'] = $reportObj->reportCountTotalMessagesByUserId($subUsersArray[$i]['childuserid'],$monthstartdate,$monthenddate);                    
                }
            }            
        }else{
                $this->view->userTypeshowing = 'locations';
                $subFoldersArray = $reportObj->findChildEntityList($userid,4); //echo "<pre>"; print_r($subFoldersArray); echo exit;
              
                $totalSubUsers = count($subFoldersArray);

                for($i = $arraystart; $i< $arrayend; $i++)
                { 
                    if(!empty($subFoldersArray[$i]))
                    {              
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['username'] = $subFoldersArray[$i]['foldername'];
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalKeywords'] = $subFoldersArray[$i]['totalkeywords'];
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalSubscribers'] = $reportObj->totalSubscribersByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalOptins'] = $reportObj->totalOptinsByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalOptouts'] = $reportObj->totalOptoutsByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate); 
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalCampaigns'] = $reportObj->totalCampaignByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalCampaignMessages'] = $reportObj->getTotalCampaignMessagesByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totaloutboundmessage'] = $reportObj->getTotalOutboundMessages($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);                        
                    }
                }
        }
    if(!empty($allDetailsArray))
    {
        $allDetailsArray['total']['username'] = '<b>Total</b>';
        $allDetailsArray['total']['totalKeywords'] = '<b>'.$reportObj->reportCountTotalKeywordByUserId($userid,$monthstartdate,$monthenddate).'</b>';  
        $allDetailsArray['total']['totalSubscribers'] = '<b>'.$reportObj->reportCountTotalSubscribersByUserId($userid,$monthstartdate,$monthenddate).'</b>';
        $allDetailsArray['total']['totalOptins'] = '<b>'.$reportObj->reportCountTotalOptinsByUserId($userid,$monthstartdate,$monthenddate).'</b>';
        $allDetailsArray['total']['totalOptouts'] = '<b>'.$reportObj->reportCountTotalOptoutsByUserId($userid,$monthstartdate,$monthenddate).'</b>';
        $allDetailsArray['total']['totalCampaignMessages'] = '<b>'.$reportObj->reportCountTotalCampaignMessagesByUserId($userid,$monthstartdate,$monthenddate).'</b>';
        $allDetailsArray['total']['totaloutboundmessage'] = '<b>'.$reportObj->reportCountTotalMessagesByUserId($userid,$monthstartdate,$monthenddate).'</b>';   
    }
        //echo "<pre>"; print_r($allDetailsArray); exit;
         
        
        $this->view->seeReportBy = $seereportby;
        $this->view->totalSubUsers = $totalSubUsers;
        $this->view->allDetailsArray = $allDetailsArray;
        $this->view->searchvalue = $searchvalue; 
        $this->view->reportuserid = $userid;
        $this->view->starttime = $this->request->getParam('starttime');
        $this->view->endtime = $this->request->getParam('endtime');
        
         if($this->request->getParam('shownumlist')!='')
         {
            $this->view->showNumList = $this->request->getParam('shownumlist');
         }else{
           $this->view->showNumList = 10;
         } 
        
         if($rmonth=='' OR $ryear=='')
         {
             $this->view->monthSelected = date('m');
             $this->view->yearSelected = date('Y');
         }else{
             $this->view->monthSelected = $rmonth;
             $this->view->yearSelected = $ryear;
         }          

    }   

    public function init()
    {
        $ajaxContext = $this->_helper->getHelper('AjaxContext');
        $ajaxContext->addActionContext('list', 'html')
                    ->addActionContext('modify', 'html')
                    ->initContext();
    }      
    public function messagemonthyearAction() { 

        $this->_helper->layout->disableLayout();
 
		$this->view->msg_limit   = $this->user->messagelimit;
		$this->view->msg_used    = $this->user->getMessageCount();
		$this->view->msg_percent = sprintf("%d", ($this->view->msg_used / $this->view->msg_limit) * 100);
		$this->view->key_limit   = $this->user->keywordlimit;
		$this->view->key_used    = $this->user->getKeywordsCount();
		$this->view->key_percent = sprintf("%d", ($this->view->key_used / $this->view->key_limit) * 100);
		
		// Large graph
		$dayrange = 30;
		$daystep  =  2;
		$this->view->graphrange   = $dayrange;
		$this->view->graphstep    = $daystep;
		$optins  = $this->user->getTotalSubscriberCountByDay($dayrange, 'asc');
		$optouts = $this->user->getDailyOptoutsByDay($dayrange, 'asc');
		$this->view->graphoptins  = $optins;
		$this->view->graphoptouts = $optouts;        
        
        $rmonth = $this->request->getParam('rmonth');
        $ryear = $this->request->getParam('ryear');
        if($rmonth=='0' OR $rmonth=='0')
        {
            $rmonth = date('n');
            $ryear = date('Y');
        } 
        $userid = $this->user->getId();
        $messageObj = new Application_Model_Report(); 
        
        
        $totalOptIns = $messageObj->getTotalOptIns($userid);
        $totalOptOuts = $messageObj->getTotalOptOuts($userid);
        $totalSubscribers = $messageObj->getTotalSubscribers($userid);
        
        $this->view->totalOptIns  = $totalOptIns;
        $this->view->totalOptOuts  = $totalOptOuts;  
        $this->view->totalSubscribers  = $totalSubscribers;   
        
        $this->view->totalCampaignMessages = $messageObj->getTotalCampaignMessagesCountByuser($userid);
        
        $this->view->totalCampaigns = $messageObj->getTotalCampaignCountByuser($userid);
             
        $monthstartdate = strtotime($ryear."-".$rmonth."-01");
        $todaydate = strtotime(date("Y-m-d"));
        $currmonthperiod = round(($todaydate - $monthstartdate)/86400); 
        
        $topThreeFolderArray = $messageObj->listTopthreeFolders($userid);
        foreach($topThreeFolderArray as $key => $topThreeFolder)
        { 
            $topThreeFolderArray[$key]['totalsubscriber'] = $messageObj->getTotalSubscriberByFolder($topThreeFolder['folderid']);
            $topThreeFolderArray[$key]['totaloptins'] = $topThreeFolder['total']; //$messageObj->totalOptinsByFolder($topThreeFolder['folderid']);
            $topThreeFolderArray[$key]['totaloptouts'] = $messageObj->totalOptoutsByFolder($topThreeFolder['folderid']);
            $topThreeFolderArray[$key]['totalcampaign'] = $messageObj->totalCampaignByFolder($topThreeFolder['folderid']);
        }//echo "<pre>"; print_r($topThreeFolderArray); exit;
        
        $topThreeKeywordArray = $messageObj->listTopthreeKeywords($userid);
        foreach($topThreeKeywordArray as $key => $topThreeKeyword)
        { 
            $topThreeKeywordArray[$key]['totalsubscriber'] = $messageObj->getTotalSubscriberByKeyword($topThreeKeyword['keywordid']);
            $topThreeKeywordArray[$key]['totaloptins'] = $topThreeKeyword['total']; //$messageObj->totalOptinsByKeyword($topThreeKeyword['keywordid']);
            $topThreeKeywordArray[$key]['totaloptouts'] = $messageObj->totalOptoutsByKeyword($topThreeKeyword['keywordid']);
            $topThreeKeywordArray[$key]['totalcampaign'] = $messageObj->totalCampaignByKeyword($topThreeKeyword['keywordid']);
        }        

        $this->view->topThreeFolderDetails = $topThreeFolderArray;
        $this->view->topThreeKeywordArray = $topThreeKeywordArray; 
        
        $this->view->totalOptIns_seven  = $messageObj->getTotalOptInsPeriod($userid,6);
        $this->view->totalOptIns_forteen  = $messageObj->getTotalOptInsPeriod($userid,13);
        $this->view->totalOptIns_thirty  = $messageObj->getTotalOptInsPeriod($userid,29);
        $this->view->totalOptIns_ninty  = $messageObj->getTotalOptInsPeriod($userid,89);
        $this->view->totalOptIns_lastyear  = $messageObj->getTotalOptInsPeriod($userid,364);             

        $this->view->totalOptOuts_seven  = $messageObj->getTotalOptOutsPeriod($userid,6);
        $this->view->totalOptOuts_forteen  = $messageObj->getTotalOptOutsPeriod($userid,13);
        $this->view->totalOptOuts_thirty  = $messageObj->getTotalOptOutsPeriod($userid,29);
        $this->view->totalOptOuts_ninty  = $messageObj->getTotalOptOutsPeriod($userid,89);
        $this->view->totalOptOuts_lastyear  = $messageObj->getTotalOptOutsPeriod($userid,364);           
        
        //$this->view->totalCampaign_currmonth  = $totalCampaign_currmonth;
        $this->view->totalCampaign_seven  = $messageObj->totalCampaignByUser($userid,7);
        $this->view->totalCampaign_forteen  = $messageObj->totalCampaignByUser($userid,14);
        $this->view->totalCampaign_thirty  = $messageObj->totalCampaignByUser($userid,30);
        $this->view->totalCampaign_ninty  = $messageObj->totalCampaignByUser($userid,90);
        $this->view->totalCampaign_lastyear  = $messageObj->totalCampaignByUser($userid,365);    
    }   
    
    public function campaignhistoryAction() {
        $userid = $this->user->getId();
        $historyObj = new Application_Model_Report();        
        $campaignhistoryArray = $historyObj->reportCampaignHistory($userid);

        if(!empty($campaignhistoryArray))
        {
            foreach($campaignhistoryArray as $campaignhistorydetail)
            { 
               //$campaignMessageStatus = $historyObj->reportCampaignMessageStatus($campaignhistorydetail['messageid']); 
               if(($campaignhistorydetail['senttime'] == NULL) OR ($campaignhistorydetail['senttime'] == '0000-00-00 00:00:00') OR ($campaignhistorydetail['senttime'] == ''))
                  $campaignhistorydetail['status']= 'Scheduled'; 
               else 
                  $campaignhistorydetail['status']= 'Sent';  
            }            
        }
        
        $this->view->campaignhistory = $campaignhistoryArray;
    }  
    
    public function campaignAction() {
        
        $historyObj = new Application_Model_Report(); 

        $userid = $this->user->getId();
        $subUsersArray = $historyObj->findChildEntityList($userid,5,"");  //echo "<pre>"; print_r($subUsersArray); exit;        
        if($this->request->getParam('locationName')!='' AND $this->request->getParam('locationName')!=0)
        {
            if($this->request->getParam('seehistoryby')=='month')
            {
                $startdate = $this->request->getParam('yearMessageReport').'-'.$this->request->getParam('monthMessageReport').'-1 00:00:00';
                $enddate = $this->request->getParam('yearMessageReport').'-'.$this->request->getParam('monthMessageReport').'-30 23:59:59';
                $campaignhistoryArray = $historyObj->reportCampaignHistoryByPeriod($this->request->getParam('locationName'),$startdate,$enddate);                
            }else
                $campaignhistoryArray = $historyObj->reportCampaignHistory($this->request->getParam('locationName'));
                
        }else{
                $campaignhistoryArray = $historyObj->reportCampaignHistory($userid);
        }

         //echo $this->request->getParam('locationName'); echo "<pre>"; print_r($campaignhistoryArray); exit;


        $this->view->campaignhistory = $campaignhistoryArray;
        $this->view->subusers = $subUsersArray;
        $this->view->monthList = $this->monthList(); 
        $this->view->yearList = $this->yearList();
        
        $this->view->monthSelected = $this->request->getParam('monthMessageReport');
        $this->view->yearSelected = $this->request->getParam('yearMessageReport');
        $this->view->locationSelected = $this->request->getParam('locationName');
        $this->view->seebySelected = $this->request->getParam('seehistoryby');
    }      
    
   public function monthList(){
       //$this->_helper->layout->disableLayout();
       $monthListArray = array(
                                '0' => '-Month-',
                                '1' => 'Jan',
                                '2' => 'Feb',
                                '3' => 'Mar',
                                '4' => 'Apr',
                                '5' => 'May',
                                '6' => 'Jun',
                                '7' => 'Jul',
                                '8' => 'Aug',
                                '9' => 'Sep',
                                '10' => 'Oct',
                                '11' => 'Nov',
                                '12' => 'Dec'
       );
       return $monthListArray;
   } 
   
   public function yearList(){
       //$this->_helper->layout->disableLayout();
       $yearListArray = array('0' => '-Year-');
       for($i=2004; $i<=date('Y');$i++)
       {
           $yearListArray[$i] = $i;
       }
       return $yearListArray;
   }    
   
   public function makeExcelReport($clientid){
       
    function cleanData(&$str) { 
        $str = preg_replace("/\t/", "\\t", $str); 
        $str = preg_replace("/\r?\n/", "\\n", $str); 
        if(strstr($str, '"')) 
                $str = '"' . str_replace('"', '""', $str) . '"'; 
    } 
// file name for download 
       $filepath = '/home/textm/textmunication.com/htdocs/public/reportdocs/';
       $filename = "weeklyreport_clientid" .$clientid.'_'. date('Ymd') . ".xls"; 
       echo $excelfile = $filepath.$filename;
       //$ourFileHandle = fopen($excelfile, 'w') or die("can't open file");
        if (!file_exists($excelfile)) {
            if(!touch($excelfile))
                echo "File can't be touched";
        } 
         
       //header("Content-Disposition: attachment; filename=\"$filename\""); 
       //header("Content-Type: application/vnd.ms-excel"); 
        header("Content-Type: text/plain");
       $reportObj = New Application_Model_Report();
       $flag = false; 
       $result = $reportObj->getWeeklyReport(); //print_r($result); exit;
       foreach($result as $row) { 
           if(!$flag) { 
// display field/column names as first row 
               //echo implode("\t", array_keys($row)) . "\r\n"; 
               $row1 = implode("\t", array_keys($row)) . "\r\n"; 
               logWrite("$row1");
               $flag = true;               
           } 
               array_walk($row, 'cleanData'); 
               //echo implode("\t", array_values($row)) . "\r\n"; 
               $row2 = implode("\t", array_values($row)) . "\r\n"; 
               logWrite("$row2");
             
       } 
  }
  
  public function sendweeklyAction(){
        $weeklyreport = new Application_Model_Report();
        $sendReportsTo = $weeklyreport->sendRportTo();
        $queueCount = count($sendReportsTo);
        $sendCount = 0;      
        if (is_array($sendReportsTo)) {
            if (!empty($sendReportsTo)) {
                foreach ($sendReportsTo as $user) { 
                    
                    $mail = new Zend_Mail();
                    $mail->setBodyText('Please see the weekly report:');
                    $mail->setFrom('reports@textmunication.com', 'Textmunication.com');
                    $mail->addTo($user['email'], 'Joseph Saunders');
                    $mail->addCc('wais@textmunication.com', 'Wais Asefi');
                    //$mail->addCc('robert.anthony.gonzalez@gmail.com', 'Robert Gonzalez');
                    $mail->setSubject('Weekly Reports');          
                            // Get the Excel model
                            $excel = new Application_Model_Excel();                    
                    if($weeklyreport->checkAdminUser($user['id']) AND $user['id']!=187)  
                    {
                        $excelDataArray = $weeklyreport->getWeeklyReport($user['id']);
                        $date = date('Ymd');
                        $excelFileName = "weeklyreport_clientid" .$user['id'].'_'. $date;
                        $excel = new Application_Model_Excel();
                        $excelFile = $excel->create($excelDataArray, $excelFileName);
                        $at = $mail->createAttachment(file_get_contents($excelFile['path']));
                        $at->filename = $excelFile['name'];                         
                       /*$subUsersArray = $weeklyreport->findChildEntityList($user['id'],5,null);
                       if(!empty($subUsersArray)){
                           foreach($subUsersArray as $subuser){
                               $excelDataArray = $weeklyreport->getWeeklyReport($subuser['childuserid']); print_r($excelDataArray);
                               $date = date('Ymd');
                               $excelFileName = "weeklyreport_clientid" .$subuser['childuserid'].'_'. $date;
                               
                               $excelFile = $excel->create($excelDataArray, $excelFileName);   echo "<pre>"; print_r($excelFile);
                               $at = $mail->createAttachment(file_get_contents($excelFile['path']));
                               $at->filename = $excelFile['name'];                                
                           }
                       }*/
                    }else{
                            // Get the subscriber datasets
                            $excelDataArray = $weeklyreport->getWeeklyReport(); //echo "<pre>"; print_r($excelDataArray);   exit;

                            // Get a date stamp for the file
                            $date = date('Ymd');

                            // Create our file names
                            $excelFileName = "weeklyreport_clientid" .$user['id'].'_'. $date;
                            

                            // Log the steps
                            //logWrite("Creating the Excel spreadsheets");

                            // Make the Excel files for each day
                            $excelFile = $excel->create($excelDataArray, $excelFileName); 
                            $at = $mail->createAttachment(file_get_contents($excelFile['path']));
                            $at->filename = $excelFile['name'];                            
                    }                                        

                    // Log the steps
                    //logWrite("Preparing to send...");
                    // Send it off
                    if (!$mail->send()) {
                        echo "MESSAGE NOT SENT";
                    } else {
                        echo "Message sent";
                    } 				
                }
            } else {
                $this->error = "No reports to send";
            }
        } else {
            $this->error = "Send to report was not properly fetched";
        }      
  }
  
    public function subscribersAction() {

             $rmonth = "";
             $ryear = "";
             $seereportby = $this->request->getParam('reportby');
             if($this->request->getParam('searchvaluehide')!='')
                    $searchvalue = $this->request->getParam('searchvaluehide');
             else
                    $searchvalue = $this->request->getParam('searchvalue');
             if($seereportby=="month")
             {
                 $rmonth = $this->request->getParam('monthMessageReport');
                 $ryear = $this->request->getParam('yearMessageReport');
                 if($rmonth==0 OR $ryear==0)
                  {
                     $monthstartdate = 0;
                     $monthenddate = 0;
                  }else{
                         $monthstartdate = $ryear."-".$rmonth."-1 00:00:00"; 
                         $monthenddate = $ryear."-".$rmonth."-30 00:00:00";                 
                 }                      
             }elseif($seereportby=="date")
             {
                $monthstartdate = date("Y-m-d",strtotime($this->request->getParam('starttime')));
                $monthenddate = date("Y-m-d",strtotime($this->request->getParam('endtime')));         
             }elseif($seereportby=="")
             {
                 $monthstartdate = date('Y')."-".date('m')."-1 00:00:00";
                 $monthenddate = date('Y')."-".date('m')."-30 00:00:00";                  
             }
        
        $reportObj =  new Application_Model_Report();
        
        $pagenum = $this->request->getParam('page');
        if($pagenum=='' OR $pagenum==0)
          $pagenum = 1;
                

        $arraystart = ($pagenum*5) - 5 ;
        $arrayend = ($pagenum*5);        
        
        if($this->request->getParam('reportuserid')!='')
              $userid = $this->request->getParam('reportuserid');
           else     
              $userid = $this->user->getId();          
        
        if($reportObj->checkAdminUser($userid))  
        {
            $this->view->userTypeshowing = 'users'; 
            $subUsersArray = $reportObj->findChildEntityList($userid,5,$searchvalue);  //echo "<pre>"; print_r($subUsersArray); exit;
            $totalSubUsers = count($subUsersArray);
            
            
            foreach ($subUsersArray as $key => $row) {
                $username[$key]  = $row['username'];
            } 
            $orderby = $this->request->getParam('orderby');
            if($orderby == 'ASC')
                array_multisort($username, SORT_ASC, $subUsersArray);
            elseif($orderby == 'DESC')
                array_multisort($username, SORT_DESC, $subUsersArray);
            //echo "<pre>"; print_r($subUsersArray); exit;    
            $this->view->sortOrderBy = $orderby;
            

            //$this->view->userlist = $subUsersArray;
            $allDetailsArray = array();

             foreach($subUsersArray as $subUser)
            {
                $allDetailsArray[$subUser['childuserid']]['username'] = $subUser['username'];
                $allDetailsArray[$subUser['childuserid']]['totalKeywords'] = $reportObj->reportCountTotalKeywordByUserId($subUser['childuserid'],$monthstartdate,$monthenddate);
                 $allDetailsArray[$subUser['childuserid']]['totalSubscribers'] = $reportObj->reportCountTotalSubscribersByUserId($subUser['childuserid']['childuserid'],$monthstartdate,$monthenddate); 
                $allDetailsArray[$subUser['childuserid']]['totalOptins'] = $reportObj->reportCountTotalOptinsByUserId($subUser['childuserid'],$monthstartdate,$monthenddate); 
                $allDetailsArray[$subUser['childuserid']]['totalOptouts'] = $reportObj->reportCountTotalOptoutsByUserId($subUser['childuserid'],$monthstartdate,$monthenddate); 
                $allDetailsArray[$subUser['childuserid']]['totalCampaigns'] = $reportObj->reportCountTotalCampaignsByUserId($subUser['childuserid'],$monthstartdate,$monthenddate); 
                $allDetailsArray[$subUser['childuserid']]['totalCampaignMessages'] = $reportObj->reportCountTotalCampaignMessagesByUserId($subUser['childuserid'],$monthstartdate,$monthenddate);
                $allDetailsArray[$subUser['childuserid']]['totaloutboundmessage'] = $reportObj->reportCountTotalMessagesByUserId($subUser['childuserid'],$monthstartdate,$monthenddate);
            }
echo "<pre>"; print_r($allDetailsArray); exit;
            
        }else{
                $this->view->userTypeshowing = 'locations';
                $subFoldersArray = $reportObj->findChildEntityList($userid,4); //echo "<pre>"; print_r($subFoldersArray); echo exit;
              
                $totalSubUsers = count($subFoldersArray);

                for($i = $arraystart; $i< $arrayend; $i++)
                { 
                    if(!empty($subFoldersArray[$i]))
                    {              
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['username'] = $subFoldersArray[$i]['foldername'];
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalKeywords'] = $subFoldersArray[$i]['totalkeywords'];
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalSubscribers'] = $reportObj->totalSubscribersByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalOptins'] = $reportObj->totalOptinsByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalOptouts'] = $reportObj->totalOptoutsByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate); 
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalCampaigns'] = $reportObj->totalCampaignByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totalCampaignMessages'] = $reportObj->getTotalCampaignMessagesByFolder($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);
                        $allDetailsArray[$subFoldersArray[$i]['folderid']]['totaloutboundmessage'] = $reportObj->getTotalOutboundMessages($subFoldersArray[$i]['folderid'],$monthstartdate,$monthenddate);                        
                    }
                }
        }
    if(!empty($allDetailsArray))
    {
        $allDetailsArray['total']['username'] = '<b>Total</b>';
        $allDetailsArray['total']['totalKeywords'] = '<b>'.$reportObj->reportCountTotalKeywordByUserId($userid,$monthstartdate,$monthenddate).'</b>';  
        $allDetailsArray['total']['totalSubscribers'] = '<b>'.$reportObj->reportCountTotalSubscribersByUserId($userid,$monthstartdate,$monthenddate).'</b>';
        $allDetailsArray['total']['totalOptins'] = '<b>'.$reportObj->reportCountTotalOptinsByUserId($userid,$monthstartdate,$monthenddate).'</b>';
        $allDetailsArray['total']['totalOptouts'] = '<b>'.$reportObj->reportCountTotalOptoutsByUserId($userid,$monthstartdate,$monthenddate).'</b>';
        $allDetailsArray['total']['totalCampaignMessages'] = '<b>'.$reportObj->reportCountTotalCampaignMessagesByUserId($userid,$monthstartdate,$monthenddate).'</b>';
        $allDetailsArray['total']['totaloutboundmessage'] = '<b>'.$reportObj->reportCountTotalMessagesByUserId($userid,$monthstartdate,$monthenddate).'</b>';   
    }
        //echo "<pre>"; print_r($allDetailsArray); exit;
         
        
        $this->view->seeReportBy = $seereportby;
        $this->view->totalSubUsers = $totalSubUsers;
        $this->view->allDetailsArray = $allDetailsArray;
        $this->view->searchvalue = $searchvalue; 
        $this->view->reportuserid = $userid;
        $this->view->starttime = $this->request->getParam('starttime');
        $this->view->endtime = $this->request->getParam('endtime');
        
         if($this->request->getParam('shownumlist')!='')
         {
            $this->view->showNumList = $this->request->getParam('shownumlist');
         }else{
           $this->view->showNumList = 10;
         } 
        
         if($rmonth=='' OR $ryear=='')
         {
             $this->view->monthSelected = date('m');
             $this->view->yearSelected = date('Y');
         }else{
             $this->view->monthSelected = $rmonth;
             $this->view->yearSelected = $ryear;
         }          

    }   
    
}
?>
