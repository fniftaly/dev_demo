<?php
class Api_MessagesController extends ApiControllerAbstract {
	public function indexAction() {
		//$this->_sendOutput('Index action called from GET');
		$this->_notImplemented();
	}
	
	public function getAction() {
		$this->setOutputParam('body', $this->_requestId ? 'You selected ID ' . $this->_requestId : 'You must specifiy a message id');
		//$this->_notImplemented();
	}
	
	/**
	 * Sends a message
	 *
	 * This method expects three parameters:
	 *  - Message
	 *  - Recipient(s)
	 *  - Location
	 *
	 * Once all three have been validated, will attempt to send a message to the
	 * target recipients.
	 *
	 */
	public function postAction() {
		$this->setOutputParam('body', $this->_request->getParams());
	}
	public function putAction() {
		//$this->_notImplemented();
		$this->setOutputParam('body', 'You requested an id');
	}
	
	public function deleteAction() {
		$this->_notImplemented();
	}
}
