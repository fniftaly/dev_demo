<?php
class Api_AuthController extends ApiControllerAbstract {
	public function indexAction() {
		$auth = new Application_Model_Auth();
		$isGood = $auth->apiCredentials('c4fb728150fd7125ca6629c73fe96020', '0d37238f35ad7dd540b4cec6ac4f032e03193a900a861421a0ec3cbad518bc65');
		//var_dump($isGood); exit;
		$this->setOutputParam('error', 'An API key and an API token must be presented in order to authenticate');
	}
	
	public function getAction() {
		$this->setOutputParam('error', 'An API key and an API token must be presented in order to authenticate');
	}
	
	public function postAction() {
		$apikey   = $this->_request->getParam('apikey');
		$apitoken = $this->_request->getParam('apitoken');
		if (!$apikey || !$apitoken) {
			$reply = array('Error' => 'An API key and an API token must be presented in order to authenticate');
		} else {
			//$this->_notImplemented();
			$auth = new Application_Model_Auth();
			$isGood = $auth->apiCredentials($apikey, $apitoken);
			if ($isGood) {
				$this->setOutputParam('body', array('AuthToken' => hash('sha256', $apikey . time())));
			} else {
				$this->setOutputParam('error','API Key / API Token mismatch');
			}
		}
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
}
