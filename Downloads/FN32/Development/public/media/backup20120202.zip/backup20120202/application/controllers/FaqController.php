<?php

class FaqController extends AuthorizedController {
    
    public function indexAction() {
        $faqs = new Application_Model_Faqs;
        
        $list = $faqs->get();
        
        $this->view->list = $list;
    }
}

