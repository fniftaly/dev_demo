<?php
/**
 * API Folder Controller class.
 * 
 * @extends ApiControllerAbstract
 */
class Api_FolderController extends ApiControllerAbstract {
    /**
	 * Folder that we are working with
	 *
	 * @access protected
	 * @var string
	 */
	protected $_folderid;
	
	/**
	 * Grab the location from the uri if it is available
	 *
	 * @access public
	 */
	public function preDispatch() {
		$this->_folderid = $this->_request->getParam('id');
		$this->_loadby   = $this->_request->getParam('field');
	}
	
    public function indexAction() {
		// Get all folders for the API user
		$folderids = $this->apiuser->getFolders();
		
		// Defaults
		$folders = array();
		$status  = true;
		$error   = array();
		
		// TODO: Not entirely happy with the way errors are handled here. I want to still return
		// valid folders, and somehow also return a folder with a problem, or some way let
		// the user know there was a problem with a folder. Also, should status be true or false
		// if there are mixed valid and invalid folders?
		
		// Build each folder
		foreach($folderids as $id) {
		   $folder = new Application_Model_Folder($this->apiuser, $id);
		   
		   // Only return if the folder is valid
		   if ($folder->isValid()) {
		        $output = array();
		        
		        $output['id']   = $folder->getId();
        		$output['name'] = $folder->name;
        		
        		$folders[] = $output;
		   } else {
		        $error[] = $folder->getError();
		        $status = false;
		   }
		}
		
		$error  = empty($error) ? null : $error;
		
		$this->setOutputParam('status', $status);
		$this->setOutputParam('error', $error);
		if ($status) $this->setOutputParam('body', $folders);
	}
    
    /**
     * Return Folder details for a passed folder id, 
     * including all subscribers to that folder and any subfolders.
     * 
     * @access public
     */
    public function getAction() {
		// Get the requested folder
		$folder = new Application_Model_Folder($this->apiuser, $this->_folderid, $this->_loadby);
		
		// Set up the return. 
		// TODO: Create a return class maybe, or some standard way to assign
		// what is returned. I was just dumping the class before, and relying
		// on property scope to control what was sent to the user, and that may work,
		// but I don't think it allows enough control.
		$output['subscribers'] = $folder->getSubscribers();
		$output['name']        = $folder->name;
		
		$this->setOutputParam('status', $folder->isValid());
		$this->setOutputParam('error', $folder->getError());
		if ($folder->isValid()) $this->setOutputParam('body', $output);
	}
	
	/**
	 * Add a Folder.
	 * 
	 * @access public
	 */
	public function postAction() {
		// Check our post array
		$post = $this->_request->getPost();
		
		if (!empty($post)) {
    		$folder = new Application_Model_Folder($this->apiuser);
    		// Add the folder and populate all meta data
    		// I did it this way so we could also add a folder (or entity)
    		// without adding any of the meta data. Maybe in the case
    		// where someone adds an entity, gets the new id, then gets
    		// the profile for that id, and populates each profile field. That
    		// will be more dynamic than someone already knowing the profile 
    		// fieldnames and passing them with the add request.
    		$folder->addWithMeta($post);
    		
    		$this->setOutputParam('status', $folder->isValid());
    		$this->setOutputParam('error', $folder->getError());
    		if ($folder->isValid()) $this->setOutputParam('body', $folder->getId());
		} else {
			$this->setOutputParam('error', 'No data was presented to create the folder with.');
		}
	}
	
	/**
	 * Update the passed folder. This can be used to update folder information,
	 * as well as add subscribers.
	 * 
	 * @access public
	 */
	public function putAction() {
		$error = null;
		
		// 1st try and get the requested folder
		$folder = new Application_Model_Folder($this->apiuser, $this->_folderid, $this->_loadby);
		
		$phonenumber = $this->getBodyParam('subscriber');
		
		// Make sure we have a valid folder and a subscriber to add
		if ($folder->isValid()) {
            if ($phonenumber) {
    		    $subscriber = new Application_Model_Subscriber;
    		    
    		    $id = $subscriber->add($phonenumber);
    		    
    		    if (!$subscriber->hasError()) {
    		        $folder->addSubscriber($id);
    		    } else {
    		        $error = $subscriber->getError();;
    		    }
            } else {
                $error = 'Must provide a subscriber to add.';
            }
		} else {
		    $error = $folder->getError();
		}
		
		$status = empty($error);
		//var_dump($folder->getSubscribers(), $subscriber); die;
		$this->setOutputParam('status', $status);
		$this->setOutputParam('error', $error);
		if ($status) $this->setOutputParam('body', array('subscribers' => $folder->getSubscribers(), 'newsubscriberid' => $id));
	}
	
	/**
	 * Delete the passed folder.
	 * 
	 * @access public
	 */
	public function deleteAction() {
		// 1st try and get the requested folder
		$folder = new Application_Model_Folder($this->apiuser, $this->_folderid, $this->_loadby);
		
		// Now deactivate it
		$folder->delete();
		
		$this->setOutputParam('status', !$folder->isActive());
		$this->setOutputParam('error', $folder->getError());
	}
}

