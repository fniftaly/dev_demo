<?php
/**
 * API Customer Controller class.
 * 
 * @extends ApiControllerAbstract
 */
class Api_CustomerController extends ApiControllerAbstract {
    /**
	 * Customer that we are working with
	 *
	 * @access protected
	 * @var string
	 */
	protected $_customerid;
	
	/**
	 * Grab the location from the uri if it is available
	 *
	 * @access public
	 */
	public function preDispatch() {
		$this->_customerid = $this->_request->getParam('id');
		$this->_loadby     = $this->_request->getParam('field');
	}
	
    /**
     * Get all customers for the current API user.
     * 
     * @access public
     * @return void
     */
    public function indexAction() {
		// Get all customers for the API user
		$customerids = $this->apiuser->getCustomers();
		
		// Defaults
		$customers = array();
		$status    = true;
		$error     = array();
		
		// TODO: Not entirely happy with the way errors are handled here. I want to still return
		// valid folders, and somehow also return a folder with a problem, or some way let
		// the user know there was a problem with a folder. Also, should status be true or false
		// if there are mixed valid and invalid folders?
		
		// Build each folder
		foreach($customerids as $id) {
		   $folder = new Application_Model_Customer($this->apiuser, $id);
		   
		   // Only return if the customer is valid
		   if ($customer->isValid()) {
		        $output = array();
		        
		        $output['id']                     = $customer->getId();
		        $output['keywordlimit']           = $customer->keywordlimit;
        		$output['name']                   = $customer->name;
        		$output['customerlocationid']     = $customer->customerlocationid;
        		$output['customerlocationnumber'] = $customer->customerlocationnumber;
        		$output['address']                = $customer->address;
        		$output['city']                   = $customer->city;
        		$output['state']                  = $customer->state;
        		$output['zip']                    = $customer->zip;
        		$output['status']                 = $customer->getStatus();
        		
        		$customers[] = $output;
		   } else {
		        $error[] = $customer->getError();
		        $status = false;
		   }
		}
		
		$error  = empty($error) ? null : $error;
		
		$this->setOutputParam('status', $status);
		$this->setOutputParam('error', $error);
		if ($status) $this->setOutputParam('body', $customers);

	}
    
    /**
     * Return Customer details for a passed customer id.
     * 
     * @access public
     */
    public function getAction() {
		// Get the requested customer
		$customer = new Application_Model_Customer($this->apiuser, $this->_customerid, $this->_loadby);
		
		// Set up the return. 
		// TODO: Create a return class maybe, or some standard way to assign
		// what is returned. I was just dumping the class before, and relying
		// on property scope to control what was sent to the user, and that may work,
		// but I don't think it allows enough control.
		$output['keywordlimit']           = $customer->keywordlimit;
		$output['name']                   = $customer->name;
		$output['customerlocationid']     = $customer->customerlocationid;
		$output['customerlocationnumber'] = $customer->customerlocationnumber;
		$output['address']                = $customer->address;
		$output['city']                   = $customer->city;
		$output['state']                  = $customer->state;
		$output['zip']                    = $customer->zip;
		$output['status']                 = $customer->getStatus();
		
		$this->setOutputParam('status', $$customer->isValid());
		$this->setOutputParam('error', $customer->getError());
		if ($customer->isValid()) $this->setOutputParam('body', $output);
	}
	
	/**
	 * Add a new Customer.
	 * 
	 * @access public
	 */
	public function postAction() {
		// Check our post array
		$post = $this->_request->getPost();
		
		if (!empty($post)) {
    		$customer = new Application_Model_Customer($this->apiuser);
    		// Add the customer and populate all meta data
    		// I did it this way so we could also add a customer (or entity)
    		// without adding any of the meta data. Maybe in the case
    		// where someone adds an entity, gets the new id, then gets
    		// the profile for that id, and populates each profile field. That
    		// will be more dynamic than someone already knowing the profile 
    		// fieldnames and passing them with the add request.
    		$customer->addWithMeta($post);
    		
    		$this->setOutputParam('status', $customer->isValid());
    		$this->setOutputParam('error', $customer->getError());
    		if ($customer->isValid()) $this->setOutputParam('body', $customer->getId());
		} else {
			$this->setOutputParam('error', 'No data was presented to create the customer with.');
		}
	}
	
	/**
	 * Update the passed customer. This can be used to update customer information.
	 * 
	 * @access public
	 */
	public function putAction() {
		$error = null;
		
		// 1st try and get the requested location
		$customer = new Application_Model_Customer($this->apiuser, $this->_customerid, $this->_loadby);
		
		// Make sure we have a valid location and a subscriber to add
		if ($customer->isValid()) {
            // Update the passed meta fields here
            /*foreach () {
            	
            }*/
            $output['keywordlimit']           = $customer->keywordlimit;
			$output['name']                   = $customer->name;
			$output['customerlocationid']     = $customer->customerlocationid;
			$output['customerlocationnumber'] = $customer->customerlocationnumber;
			$output['address']                = $customer->address;
			$output['city']                   = $customer->city;
			$output['state']                  = $customer->state;
			$output['zip']                    = $customer->zip;
			$output['status']                 = $customer->getStatus();
		} else {
		    $error = $customer->getError();
		}
		
		$status = empty($error);
		
		$this->setOutputParam('status', $status);
		$this->setOutputParam('error', $error);
		if ($status) $this->setOutputParam('body', $output));
	}
	
	/**
	 * Delete the passed location.
	 * 
	 * @access public
	 */
	public function deleteAction() {
		// 1st try and get the requested customer
		$customer = new Application_Model_Customer($this->apiuser, $this->_customerid, $this->_loadby);
		
		// Now deactivate it
		$customer->delete();
		
		$this->setOutputParam('status', !$customer->isActive());
		$this->setOutputParam('error', $customer->getError());
	}
}

