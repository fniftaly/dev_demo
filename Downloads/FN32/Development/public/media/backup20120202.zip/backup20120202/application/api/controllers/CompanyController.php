<?php
class Api_CompanyController extends ApiControllerAbstract {
    
    public function indexAction() {
		$this->_notImplemented();
	}
    
    public function getAction() {
		$this->_notImplemented();
	}
	
	public function postAction() {
		$company = new Application_Model_Entity();
		
		$company->addEntity(, $createuser, $parententity);
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
}

