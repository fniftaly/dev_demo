<?php
class Api_ClientController extends ApiControllerAbstract {
    
    public function indexAction() {
		$this->_notImplemented();
	}
    
    public function getAction() {
		$this->_notImplemented();
	}
	
	public function postAction() {
		$this->_notImplemented();
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
}

