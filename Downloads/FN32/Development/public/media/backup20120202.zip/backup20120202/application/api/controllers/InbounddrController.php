<?php
class Api_InbounddrController extends ApiControllerAbstract {
	/**
	 * Object initializer
	 * 
	 * @see Zend_Controller_Action::init()
	 */
	public function init() {
		// Tells the framework to not render view templates or layouts
		$this->_helper->viewRenderer->setNoRender(true);
		$this->_helper->layout()->disableLayout();
	}
	
	public function indexAction() {
		$this->_notImplemented();
	}
	
	public function getAction() {
		$this->_notImplemented();
	}
	
	public function postAction() {
		// Write to the status update to the db 
		//$status = new Application_Model_Smsinbound;
		$dr = new Application_Model_Deliveryreport();
		$dr->loadFromArray($this->_request->getPost());
		$dr->writeLog();
		/*
		$dr->device_address = $this->_request->getPost('device_address');
		$dr->inbound_address = $this->_request->getPost('inbound_address');
		$dr->router = $this->_request->getPost('router');
		$dr->carrier = $this->_request->getPost('carrier');
		$dr->channel = $this->_request->getPost('channel');
		$dr->smscid = $this->_request->getPost('smscid');
		$dr->message_id = $this->_request->getPost('message_id');
		$dr->message_subid = $this->_request->getPost('message_subid');
		$dr->status = $this->_request->getPost('status');
		$dr->status_code = $this->_request->getPost('status_code');
		$dr->status_info = $this->_request->getPost('status_info');
		$dr->date_format = $this->_request->getPost('date_format');
		$dr->update_date = $this->_request->getPost('update_date');
		$dr->reportingkey1 = $this->_request->getPost('reporting_key1');
		$dr->reportingkey2 = $this->_request->getPost('reporting_key2');
		$dr->save();
		*/
		/*
		$log = realpath(dirname(__FILE__)) . '/logdr.txt';
		ob_start();
		echo "POST:\n";
		var_dump($_POST);
		echo "\nGET\n";
		var_dump($_GET);
		$write = ob_get_contents();
		ob_end_clean();
		$fh = fopen($log, 'a');
		fwrite($fh, "\n$write\n");
		fclose($fh);
		*/
		$this->setOutputParam('message', 'Message received');
	}
	
	public function putAction() {
		$this->_notImplemented();
	}
	public function deleteAction() {
		$this->_notImplemented();
	}
}
