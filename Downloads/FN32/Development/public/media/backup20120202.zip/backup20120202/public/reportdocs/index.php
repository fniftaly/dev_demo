<?php

header("location:/");
